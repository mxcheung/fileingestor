package au.com.lonsec.fileingestor.fileupload.filter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KeySetRowFilter implements RowFilter {

    private static final String ROW_NUM = "rowNum";

    private static final Logger LOGGER = LoggerFactory.getLogger(KeySetRowFilter.class);

    private final Set<String> keySet;

    public KeySetRowFilter(Set<String> keySet) {
        this.keySet = keySet;
    }

    /*
     * (non-Javadoc)
     * 
     * @see au.com.lonsec.fileingestor.fileupload.filter.RowFilter#filter(java.util.List)
     */
    @Override
    public List<Map<String, Object>> filter(List<Map<String, Object>> dataRows) {

        List<Map<String, Object>> filteredRows = new ArrayList<Map<String, Object>>();
        for (Map<String, Object> dataRow : dataRows) {
            if (isEmpty(dataRow, keySet)) {
                LOGGER.info("Exclude row :" + dataRow);
            } else {
                filteredRows.add(dataRow);
            }
        }
        return filteredRows;
    }

    private boolean isEmpty(Map<String, Object> datarow, Set<String> keys) {
        Map<String, Object> rowCheck = new HashMap<String, Object>();
        rowCheck.putAll(datarow);
        rowCheck.keySet().remove(ROW_NUM);
        rowCheck.keySet().removeAll(keys);
        rowCheck.values().removeIf(Objects::isNull);
        rowCheck.values().removeIf(x -> x == "");
        return rowCheck.isEmpty();
    }

}
