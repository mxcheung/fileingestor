package au.com.lonsec.fileingestor.fileupload.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.lonsec.fileingestor.filespec.model.ColumnDefinition;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.ValidationDTO;
import au.com.lonsec.fileingestor.fileupload.model.ValidationError;
import au.com.lonsec.fileingestor.validation.server.ValidationService;

@Service
public class RowValidator {

    private static final String EMPTY_STRING = "";
    private static final String SPEL_VARIABLE_PREFIX = "#";
    private final ValidationService validationService;

    @Autowired
    RowValidator(ValidationService validationService) {
        this.validationService = validationService;
    }

    public void validateRows(ReportDefinition reportDefinition, List<ValidationDTO> validationDTOs) {
        for (ValidationDTO validationDTO : validationDTOs) {
            List<ValidationError> validationErrors = fetchValidationErrors(reportDefinition, validationDTO);
            boolean hasErrors = validationErrors.size() > 0;
            validationDTO.setValidationErrors(validationErrors);
            validationDTO.setContainsErrors(hasErrors);
        }
    }

    private List<ValidationError> fetchValidationErrors(ReportDefinition reportDefinition, ValidationDTO validationDTO) {
        List<ValidationError> validationErrors = new ArrayList<ValidationError>();
        validationErrors = validationService.validatevalidationDTO(validationDTO, reportDefinition.getValidationRules());
        updateColumnNumberValidationError(reportDefinition.getColumnDefinitions(), validationErrors);
        return validationErrors;
    }

    public List<ColumnDefinition> updateColumnNumberValidationError(List<ColumnDefinition> columns, List<ValidationError> validationErrors) {
        validationErrors.forEach(new Consumer<ValidationError>() {
            public void accept(ValidationError validationError) {
                Optional<ColumnDefinition> columnDefinition = getColumnByTargetName(columns, validationError.getFieldName());
                columnDefinition.ifPresent(col -> validationError.setColNum(col.getColumnIdx()));
            }
        });
        return columns;
    }

    public Optional<ColumnDefinition> getColumnByTargetName(List<ColumnDefinition> columns, String targetName) {
        for (ColumnDefinition column : columns) {
            String colName = column.getTargetName();
            targetName = targetName.replace(SPEL_VARIABLE_PREFIX, EMPTY_STRING);
            if (targetName.equalsIgnoreCase(colName)) {
                return Optional.of(column);
            }
        }
        return Optional.empty();
    }

}
