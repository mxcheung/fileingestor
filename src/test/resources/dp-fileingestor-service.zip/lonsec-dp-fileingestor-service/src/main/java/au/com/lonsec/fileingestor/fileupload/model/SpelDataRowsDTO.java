package au.com.lonsec.fileingestor.fileupload.model;

import java.util.List;
import java.util.Map;

public class SpelDataRowsDTO {

    private List<Map<String, Object>> dataRows;

    public List<Map<String, Object>> getDataRows() {
        return dataRows;
    }

    public void setDataRows(List<Map<String, Object>> dataRows) {
        this.dataRows = dataRows;
    }

}
