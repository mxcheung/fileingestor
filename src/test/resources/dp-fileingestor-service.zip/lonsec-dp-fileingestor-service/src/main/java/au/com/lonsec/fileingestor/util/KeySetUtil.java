package au.com.lonsec.fileingestor.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

public final class KeySetUtil {

    private KeySetUtil() {
    }

    public static String getKey(Map<String, Object> row, Set<String> columnKeys) {
        List<String> keyVal = new ArrayList<String>();
        for (String columnKey : columnKeys) {
            String keyValue = (String) row.get(columnKey);
            if (StringUtils.isNotBlank(keyValue)) {
                keyVal.add(keyValue);
            }
        }
        return keyVal.stream().collect(Collectors.joining(","));

    }

}
