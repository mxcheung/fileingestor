package au.com.lonsec.fileingestor.validation.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.SpelEvaluationException;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Service;

import au.com.lonsec.fileingestor.fileupload.model.SpelDataRowsDTO;
import au.com.lonsec.fileingestor.fileupload.model.ValidationDTO;
import au.com.lonsec.fileingestor.fileupload.model.ValidationError;
import au.com.lonsec.fileingestor.validation.model.ValidationRequest;
import au.com.lonsec.fileingestor.validation.model.ValidationRule;
import au.com.lonsec.fileingestor.validation.util.SpelUtil;

@Service
public class ValidationService {

    private static final String DERIVED_VALUE = "value";

    private static final String DATA_SET = "dataSet";

    private static final Logger LOGGER = LoggerFactory.getLogger(ValidationService.class);

    private ExpressionParser parser;

    private final StandardEvaluationContext itemContext;

    public ValidationService() throws NoSuchMethodException, SecurityException {
        itemContext = SpelUtil.getContext();
        parser = new SpelExpressionParser();
    }

    public List<ValidationError> validatevalidationDTO(ValidationRequest validationRequest) {
        boolean rowLevel = false;
        rowLevel = (validationRequest.getValidationDTO().getData() != null);
        List<ValidationError> errors;
        if (rowLevel) {
            errors = validatevalidationDTO(validationRequest.getValidationDTO(), validationRequest.getValidationRules());
        } else {
            errors = validationGroupItem(validationRequest.getValidationDTO(), validationRequest.getValidationRules());
        }
        return errors;
    }

    public List<ValidationError> validatevalidationDTO(ValidationDTO validationDTO, List<ValidationRule> validationRules) {
        List<ValidationError> validationErrors = new ArrayList<ValidationError>();
        for (ValidationRule validationRule : validationRules) {
            Optional<ValidationError> validationError = validationItem(validationDTO, validationRule);
            validationError.ifPresent(error -> validationErrors.add(error));
        }
        return validationErrors;
    }

    public List<ValidationError> validationGroupItem(ValidationDTO validationDTO, List<ValidationRule> validationRules) {
        List<ValidationError> validationErrors = new ArrayList<ValidationError>();
        if (validationRules != null) {
            for (ValidationRule validationRule : validationRules) {
                Optional<ValidationError> validationError = validationGroupItem(validationDTO, validationRule);
                validationError.ifPresent(error -> validationErrors.add(error));
            }
        }
        return validationErrors;
    }

    public Optional<ValidationError> validationItem(ValidationDTO validationDTO, ValidationRule validationRule) {

        try {
            Map<String, Object> model = validationDTO.getData();
            itemContext.setVariables(model);
            Expression expresion = parser.parseExpression(validationRule.getExpression());
            boolean result = expresion.getValue(itemContext, Boolean.class);
            if (!result) {
                return generateErrorMsg(validationDTO, validationRule);
            }
        } catch (SpelEvaluationException e) {
            LOGGER.error("Error occured during SpelEvaluation", e);
            return Optional.empty();
        }
        return Optional.empty();
    }

    private Optional<ValidationError> validationGroupItem(ValidationDTO validationDTO, ValidationRule validationRule) {

        try {

            List<Map<String, Object>> dataRows = validationDTO.getDataRows();
            SpelDataRowsDTO spelDataRowsDTO = new SpelDataRowsDTO();
            spelDataRowsDTO.setDataRows(dataRows);
            Map<String, Object> variables = new HashMap<String, Object>();
            variables.put(DATA_SET, spelDataRowsDTO);
            itemContext.setVariables(variables);
            Expression valueExpresssion = parser.parseExpression(validationRule.getKey());
            Object derivedTotal = valueExpresssion.getValue(itemContext, Object.class);
            variables.put(DERIVED_VALUE, derivedTotal);
            itemContext.setVariables(variables);
            Expression ruleExpression = parser.parseExpression(validationRule.getExpression());
            boolean result = ruleExpression.getValue(itemContext, Boolean.class);
            if (!result) {
                return generateErrorMsg(validationDTO, validationRule);
            }
        } catch (SpelEvaluationException e) {
            LOGGER.error("Error occured during SpelEvaluation", e);

            return Optional.empty();
        }
        return Optional.empty();
    }

    private Optional<ValidationError> generateErrorMsg(ValidationDTO validationDTO, ValidationRule validationRule) {
        Expression errorMessageExpresssion = parser.parseExpression(validationRule.getMessage());
        String errorMessage = errorMessageExpresssion.getValue(itemContext, String.class);
        ValidationError validationError = new ValidationError();
        validationError.setMessage(errorMessage);
        validationError.setFieldName(validationRule.getKey());
        validationError.setRowNum(validationDTO.getRowNum());
        return Optional.of(validationError);
    }

}
