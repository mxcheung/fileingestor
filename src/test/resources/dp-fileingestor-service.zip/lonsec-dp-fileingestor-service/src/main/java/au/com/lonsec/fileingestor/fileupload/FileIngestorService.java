package au.com.lonsec.fileingestor.fileupload;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.fileupload.model.BatchDTO;
import au.com.lonsec.fileingestor.fileupload.model.FileDTO;
import au.com.lonsec.fileingestor.fileupload.model.ResultDTO;
import au.com.lonsec.fileingestor.util.FileUtil;
import au.com.lonsec.fileingestor.util.JSONHelper;

@Service
public class FileIngestorService {


    private static final String QUEUED =  FileStatusType.QUEUED.name();
    private static final String PROCESSED =  FileStatusType.PROCESSED.name();

    private static final Logger LOGGER = LoggerFactory.getLogger(FileIngestorService.class);

    private final FileService fileService;

    private final BatchRepository batchRepository;

    private final FileProcessorService fileProcessorService;

    private final FileMapper fileMapper;

    private ObjectMapper mapper;

    @Autowired
    FileIngestorService(FileProcessorService fileProcessorService, FileService fileService, FileContentRepository fileContentRepository,
            BatchRepository batchRepository, FileMapper fileMapper) {
        this.fileProcessorService = fileProcessorService;
        this.fileService = fileService;
        this.batchRepository = batchRepository;
        this.fileMapper = fileMapper;
        mapper = JSONHelper.getObjectMapper();
    }

    public ResultDTO importData(MultipartFile uploadfile, String fileSpec) throws IOException, OpenXML4JException {
        LOGGER.info("importData {}", uploadfile.getOriginalFilename());
        return fileProcessorService.importData(uploadfile, fileSpec);
    }

    public BatchDTO getBatchSummary(Long batchId) {
        BatchEntity batchEntity = batchRepository.findOne(batchId);
        List<FileEntity> fileEntitys = fileService.findByBatchId(batchId);
        List<FileDTO> fileDTOs = convert(fileEntitys);
        BatchDTO batchDTO = getBatchSummary(batchEntity, fileDTOs);
        return batchDTO;
    }

    public BatchDTO getBatchSummary(BatchEntity batchEntity, List<FileDTO> fileDTOs) {
        BatchDTO batchDTO = new BatchDTO();
        batchDTO.setId(batchEntity.getId());
        batchDTO.setBatchFileCreated(batchEntity.getInsertDate());
        batchDTO.setFiles(fileDTOs);
        String status = getBatchStatus(fileDTOs);
        batchDTO.setStatus(status);
        Long lastBatchFiIed = 0L;
        if (fileDTOs != null) {
            if (fileDTOs.size() > 0) {
                FileDTO fileDTO = fileDTOs.get(0);
                batchDTO.setBatchFileId(fileDTO.getId());
                int batchSize = fileDTOs.size();
                FileDTO lastfileDTO = fileDTOs.get(batchSize - 1);
                lastBatchFiIed = lastfileDTO.getId();
            }
        }
        FileEntity lastProcessedFileEntity = fileProcessorService.getLastProcessedFileEntity();

        if (lastProcessedFileEntity != null) {
            Long lastProcessFileId = lastProcessedFileEntity.getId();
            Long queueDepth = lastBatchFiIed - lastProcessFileId;
            batchDTO.setLastProcessedFileId(lastProcessedFileEntity.getId());
            batchDTO.setLastProcessedFileTimeStamp(lastProcessedFileEntity.getLastModified());
            batchDTO.setQueueDepth(queueDepth);
        }
        return batchDTO;
    }

    public String getBatchStatus(List<FileDTO> fileDTOs) {
        List<FileDTO> queuedFiles = fileDTOs.stream().filter(item -> QUEUED.equals(item.getStatus())).collect(Collectors.toList());
        String status = queuedFiles.size() > 0 ? QUEUED :  PROCESSED;
        return status;
    }

    private List<FileDTO> convert(List<FileEntity> fileEntitys) {
        List<FileDTO> fileDTOs = new ArrayList<FileDTO>();
        for (FileEntity fileEntity : fileEntitys) {
            FileDTO fileDTO = fileMapper.map(fileEntity, new FileDTO());
            fileDTOs.add(fileDTO);
        }
        return fileDTOs;
    }

    @Transactional
    public FileDTO getFileErrors(Long fileId) throws JsonParseException, JsonMappingException, IOException {
        FileEntity fileEntity = fileService.fetchFileEntity(fileId);
        FileContentEntity fileContent = fileEntity.getFileContentEntity();
        byte[] compressedData = fileContent.getResultContent();
        byte[] uncompressedData = FileUtil.gzipUncompress(compressedData);
        String json = new String(uncompressedData);
        ResultDTO resultDTO = mapper.readValue(json, ResultDTO.class);
        FileDTO fileDTO = new FileDTO();
        fileDTO.setStatus(fileEntity.getStatus());
        fileDTO.setOriginalFileName(fileEntity.getOriginalFileName());
        fileDTO.setErrorDatasets(fileEntity.getErrorDatasets());
        fileDTO.setTotalDatasets(fileEntity.getTotalDatasets());
        fileDTO.setResultDTO(resultDTO);
        return fileDTO;
    }

}