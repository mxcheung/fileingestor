package au.com.lonsec.fileingestor.validation.server;

import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import au.com.lonsec.fileingestor.fileupload.model.ValidationError;
import au.com.lonsec.fileingestor.validation.model.ValidationRequest;

@RestController
@RequestMapping(value = ValidationURI.VALIDATION_BASE_CONTEXT)
public class ValidationController {

    @Autowired
    private ValidationService validationService;

    @RequestMapping(value = ValidationURI.POST_VALIDATE_MAPPING, method = POST)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<List<ValidationError>> validateHolding(@RequestBody final ValidationRequest validationRequest,
            @RequestHeader(value = "Authorization", required = false) final String authToken) {
        List<ValidationError> result = validationService.validatevalidationDTO(validationRequest);
        return new ResponseEntity<List<ValidationError>>(result, HttpStatus.OK);
    }

}
