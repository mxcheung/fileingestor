package au.com.lonsec.fileingestor.fileupload.validator;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Service;

import au.com.lonsec.fileingestor.filespec.model.ColumnDefinition;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.SectionDTO;
import au.com.lonsec.fileingestor.util.KeySetUtil;

@Service
public class SectionSplitter {

    public List<SectionDTO> convertToSections(ReportDefinition reportDefinition, Sheet sheet, List<Map<String, Object>> dataRows) {

        List<SectionDTO> sections = new ArrayList<SectionDTO>();

        Set<String> keySet = getKeySet(reportDefinition.getColumnDefinitions());

        List<Map<String, Object>> sectionRows = new ArrayList<Map<String, Object>>();
        String prevKey = "";
        String currentKey = "";
        for (Map<String, Object> dataRow : dataRows) {
            currentKey = KeySetUtil.getKey(dataRow, keySet);
            if (isSectionBreak(prevKey, currentKey)) {
                sectionRows = new ArrayList<Map<String, Object>>();
                // String sectionKey = APIR_CD;
                SectionDTO sectionDTO = new SectionDTO();
                sectionDTO.setSheetName(sheet.getSheetName());
                sectionDTO.setSectionName(currentKey);
                sectionDTO.setDataRows(sectionRows);
                sections.add(sectionDTO);
            }

            sectionRows.add(dataRow);
            prevKey = currentKey;
        }
        return sections;
    }

    public Set<String> getKeySet(List<ColumnDefinition> columns) {
        Set<String> keySet = new HashSet<String>();
        for (ColumnDefinition column : columns) {
            if (column.getPrimaryKey()) {
                keySet.add(column.getTargetName());
            }

        }
        return keySet;
    }

    public Set<String> getDataSetUniqueKeys(List<Map<String, Object>> dataRows, Set<String> columnKeys) {
        Set<String> keys = new HashSet<String>();
        for (Map<String, Object> dataRow : dataRows) {
            String keyVal = KeySetUtil.getKey(dataRow, columnKeys);
            keys.add(keyVal);
        }
        return keys;
    }

    /*
     * public boolean isSectionBreak(String field1, String field2) { return (!StringUtils.isEmpty(field1) &&
     * (field2 == null)); }
     */
    public boolean isSectionBreak(String field1, String field2) {
        return !field1.equalsIgnoreCase(field2);
    }

}
