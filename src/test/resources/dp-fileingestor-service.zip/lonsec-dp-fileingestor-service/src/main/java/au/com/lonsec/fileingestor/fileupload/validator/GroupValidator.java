package au.com.lonsec.fileingestor.fileupload.validator;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.ValidationDTO;
import au.com.lonsec.fileingestor.fileupload.model.ValidationError;
import au.com.lonsec.fileingestor.validation.server.ValidationService;

@Service
public class GroupValidator {

    private final ValidationService validationService;

    @Autowired
    GroupValidator(ValidationService validationService) {
        this.validationService = validationService;
    }

    public ValidationDTO validateGroupData(ReportDefinition reportDefinition, ValidationDTO validationDTO) {
        List<ValidationError> validationErrors = validationService.validationGroupItem(validationDTO, reportDefinition.getGroupValidationRules());
        boolean hasErrors = validationErrors.size() > 0;
        validationDTO.setValidationErrors(validationErrors);
        validationDTO.setContainsErrors(hasErrors);
        return validationDTO;
    }

}
