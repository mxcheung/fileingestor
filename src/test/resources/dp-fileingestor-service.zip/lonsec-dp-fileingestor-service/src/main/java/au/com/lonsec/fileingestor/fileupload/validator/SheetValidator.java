package au.com.lonsec.fileingestor.fileupload.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.lonsec.fileingestor.filespec.model.ColumnDefinition;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.DataSetDTO;
import au.com.lonsec.fileingestor.fileupload.model.SectionDTO;
import au.com.lonsec.fileingestor.poi.PoiService;

@Service
public class SheetValidator {

    private static final Logger LOGGER = LoggerFactory.getLogger(SheetValidator.class);

    private final SectionValidator sectionValidator;

    private final PoiService poiService;

    private final SectionSplitter sectionSplitter;

    @Autowired
    SheetValidator(PoiService poiService, SectionValidator sectionValidator, SectionSplitter sectionSplitter) {
        this.poiService = poiService;
        this.sectionValidator = sectionValidator;
        this.sectionSplitter = sectionSplitter;
    }

    public List<DataSetDTO> validateSheet(ReportDefinition reportDefinition, Sheet sheet) {
        LOGGER.info("validating sheet" + sheet.getSheetName());
        List<ColumnDefinition> columns = reportDefinition.getColumnDefinitions();
        columns = mapColumns(reportDefinition, columns, sheet);
        boolean isValidSheet = isColumnsMapped(columns);
        List<DataSetDTO> dataSetDTOs = new ArrayList<DataSetDTO>();
        if (isValidSheet) {
            List<Map<String, Object>> dataRows = poiService.getDataRows(sheet, reportDefinition.getColumnDefinitions(),
                    reportDefinition.getDataStartRow());
            List<SectionDTO> sections = sectionSplitter.convertToSections(reportDefinition, sheet, dataRows);
            List<DataSetDTO> sectionDataSetDTOs = validateSections(reportDefinition, sections);
            dataSetDTOs.addAll(sectionDataSetDTOs);
        }
        return dataSetDTOs;
    }

    public List<DataSetDTO> validateSections(ReportDefinition reportDefinition, List<SectionDTO> sections) {
        List<DataSetDTO> dataSetDTOs = new ArrayList<DataSetDTO>();
        for (SectionDTO section : sections) {
            DataSetDTO dataSetDTO = sectionValidator.validateSection(reportDefinition, section);
            dataSetDTOs.add(dataSetDTO);
        }
        return dataSetDTOs;
    }

    // Map columnns based on sheet
    private List<ColumnDefinition> mapColumns(ReportDefinition reportDefinition, List<ColumnDefinition> columns, Sheet sheet) {
        Row row = poiService.getRow(sheet, reportDefinition.getHeaderStartRow());
        Map<String, Integer> headersMap = poiService.getRowToHeadersMap(row);
        columns = poiService.mapColumns(columns, headersMap);
        return columns;
    }

    public boolean isColumnsMapped(List<ColumnDefinition> columns) {
        for (ColumnDefinition column : columns) {
            if (column.getColumnIdx() == null) {
                return false;
            }
        }
        return true;
    }

}
