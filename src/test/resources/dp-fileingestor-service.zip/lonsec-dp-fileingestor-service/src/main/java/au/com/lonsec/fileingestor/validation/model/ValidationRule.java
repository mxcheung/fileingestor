package au.com.lonsec.fileingestor.validation.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "key", "expression", "message" })
public class ValidationRule {

    private String key;
    private String expression;;
    private String message;

    @JsonCreator
    public ValidationRule(@JsonProperty("key") String key, @JsonProperty("expression") String expression, @JsonProperty("message") String message) {
        super();
        this.key = key;
        this.expression = expression;
        this.message = message;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getExpression() {
        return expression;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
