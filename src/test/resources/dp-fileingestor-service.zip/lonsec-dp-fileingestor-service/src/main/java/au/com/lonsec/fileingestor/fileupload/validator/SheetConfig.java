package au.com.lonsec.fileingestor.fileupload.validator;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import au.com.lonsec.fileingestor.filespec.FileSpecService;
import au.com.lonsec.fileingestor.filespec.model.ColumnDefinition;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.FileSpecNotFoundException;
import au.com.lonsec.fileingestor.fileupload.MappingSheetNotFoundException;
import au.com.lonsec.fileingestor.poi.RowMapper;

@Service
public class SheetConfig {

    private static final String SYSTEM = "SYSTEM";
    private static final String COLUMNDEFINITION = "COLUMNDEFINITION";
    private static final RowMapper ROWMAPPER = new RowMapper();

    private final FileSpecService fileSpecService;

    @Autowired
    SheetConfig(FileSpecService fileSpecService) {
        this.fileSpecService = fileSpecService;
    }

    public void loadConfig(ReportDefinition reportDefinition, Sheet mappingSheet) {
        Multimap<String, Row> map = getMultiMap(mappingSheet);
        Map<String, Object> columnDefs = convert(map.get(COLUMNDEFINITION));
        Map<String, Object> systemMap = convert(map.get(SYSTEM));
        overrideColumns(reportDefinition, columnDefs);
        overrideSystem(reportDefinition, systemMap);
    }

    public ReportDefinition overrideSystem(ReportDefinition reportDefinition, Map<String, Object> systemMap) {
        Object headerStartRow = systemMap.get("headerStartRow");
        Object dataStartRow = systemMap.get("dataStartRow");

        if (headerStartRow != null) {
            reportDefinition.setHeaderStartRow(ROWMAPPER.getIntValue(headerStartRow));
        }
        if (dataStartRow != null) {
            reportDefinition.setDataStartRow(ROWMAPPER.getIntValue(dataStartRow));
        }
        return reportDefinition;
    }

    private void overrideColumns(ReportDefinition reportDefinition, Map<String, Object> map) {
        List<ColumnDefinition> columns = reportDefinition.getColumnDefinitions();
        for (ColumnDefinition column : columns) {
            String key = column.getTargetName();
            Object value = map.get(key);
            if (value != null) {
                column.setSourceName(value.toString());
            }
        }
    }

    private Map<String, Object> convert(Collection<Row> rows) {
        Map<String, Object> map = new HashMap<String, Object>();
        for (Row row : rows) {
            String k = (String) ROWMAPPER.getCellValue(row.getCell(1));
            Object v = ROWMAPPER.getCellValue(row.getCell(2));
            map.put(k, v);
        }
        return map;
    }

    private Multimap<String, Row> getMultiMap(Sheet sheet) {
        Multimap<String, Row> map = ArrayListMultimap.create();
        for (Row row : sheet) {

            short x = row.getFirstCellNum();
            Cell cell = row.getCell(x);
            String cellVal = (String) ROWMAPPER.getCellValue(cell);
            map.put(cellVal, row);
        }
        return map;
    }

    public ReportDefinition getReportDefinition(String fileSpec) throws IOException {
        return fileSpecService.getReportDefinition(fileSpec);
    }

    public ReportDefinition getReportDefinition(Sheet mappingSheet)
            throws IOException, MappingSheetNotFoundException, FileSpecNotFoundException {
        String fileSpec = getFileSpec(mappingSheet);
        return getReportDefinition(fileSpec);
    }

    public String getFileSpec(Sheet mappingSheet) throws FileSpecNotFoundException {
        Multimap<String, Row> map = getMultiMap(mappingSheet);
        Map<String, Object> systemMap = convert(map.get(SYSTEM));
        Object fileSpec = systemMap.get("fileSpec");
        if (fileSpec == null) {
            throw new FileSpecNotFoundException("Unable to file spec");
        }
        return fileSpec.toString();
    }

}
