package au.com.lonsec.fileingestor.queue;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Service;

import au.com.lonsec.fileingestor.fileupload.FileProcessorService;
import au.com.lonsec.fileingestor.fileupload.QueueRepository;

@Service
public class FileIngestorExecutorService implements ApplicationListener<ApplicationReadyEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileIngestorExecutorService.class);

    private static final int CONSUMERS = 1;

    private final FileProcessorService  fileProcessorService;
    private final List<Thread> consumers;

    private final FileIngestorQueueService fileIngestorQueueService;
    private final FileProducer fileProducer;

    @Autowired
    FileIngestorExecutorService(FileProcessorService fileProcessorService, QueueRepository queueRepository, FileProducer fileProducer,
            FileIngestorQueueService fileIngestorQueueService) {
        this.fileProcessorService = fileProcessorService;
        this.fileIngestorQueueService = fileIngestorQueueService;
        this.fileProducer = fileProducer;
        consumers = createConsumers();
    }

    @Override
    public void onApplicationEvent(final ApplicationReadyEvent event) {
        LOGGER.info("initialising startup.");
        try {
            initialise();
        } catch (InterruptedException e) {
            LOGGER.error("Unexpected error during initialisation {} ", e);
        }
    }

    public void initialise() throws InterruptedException {
        startConsumers();
        fileProducer.recoverJobs();
    }

    private void startConsumers() {
        LOGGER.info("starting consumers.");
        for (Thread consumer : consumers) {
            consumer.start();
        }
    }

    public List<Thread> createConsumers() {
        List<Thread> threads = new ArrayList<Thread>();
        for (int j = 0; j < CONSUMERS; j++) {
            threads.add(new Thread(new FileConsumer(fileProcessorService, fileIngestorQueueService)));
        }
        return threads;
    }

    public List<Thread> getConsumers() {
        return consumers;
    }

}
