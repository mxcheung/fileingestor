package au.com.lonsec.fileingestor.poi;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;

import au.com.lonsec.fileingestor.filespec.model.ColumnDefinition;
import au.com.lonsec.fileingestor.fileupload.filter.KeySetRowFilter;
import au.com.lonsec.fileingestor.fileupload.filter.RowFilter;

@Component
public class PoiService {

    private static final String XLS = "XLS";

    private static final Logger LOGGER = LoggerFactory.getLogger(PoiService.class);

    private final RowMapper xLMapper;

    public PoiService() {
        xLMapper = new RowMapper();
    }

    /**
     * @param excelFileToRead - Input stream that contains the workbook.
     * @param fileExt File extension XLS or XLSX.
     * @return List of sheets.
     * @throws InvalidFormatException File not XLS or XLSX.
     * @throws IOException Exception ocurred while load file input stream.
     */
    public List<Sheet> extractSheets(InputStream excelFileToRead, String fileExt) throws InvalidFormatException, IOException {
        LOGGER.info("extracting sheets ....");
        List<Sheet> wbData = new ArrayList<Sheet>();

        final Workbook workbook;
        if (fileExt.equalsIgnoreCase(XLS)) {
            workbook = new HSSFWorkbook(excelFileToRead);

        } else {

            workbook = new XSSFWorkbook(excelFileToRead);

        }
        for (Sheet sheet : workbook) {
            wbData.add(sheet);
        }
        workbook.close();
        return wbData;
    }

    public Row getRow(Sheet sheet, int rownum) {
        return sheet.getRow(rownum);
    }

    public Map<String, Integer> getRowToHeadersMap(Row row) {
        Map<String, Integer> map = new HashMap<String, Integer>();
        if (row != null) {
            for (Cell cell : row) {
                int i = cell.getColumnIndex();
                Object obj = getCellValue(cell);
                if (obj != null) {
                    String cellValue = obj.toString();
                    map.put(cellValue, i);
                }
            }
        }
        return map;
    }

    public List<Map<String, Object>> getDataRows(Sheet sheet, List<ColumnDefinition> headers, int dataIdx) {
        RowFilter filter = new KeySetRowFilter(getKeySet(headers));
        List<Map<String, Object>> dataRows = new ArrayList<Map<String, Object>>();
        for (Row row : sheet) {
            if (row.getRowNum() >= dataIdx) {
                if (!xLMapper.isRowEmpty(row)) {
                    dataRows.add(rowToMap(headers, row));
                }
            }
        }
        return filter.filter(dataRows);
    }
    
    
    public Set<String> getKeySet(List<ColumnDefinition> columnDefinitions) {
        Set<String> keySet = new HashSet<String>();
        for (ColumnDefinition column : columnDefinitions) {
            if (column.getPrimaryKey()) {
                keySet.add(column.getTargetName());
            }
        }
        return keySet;
    }

    public List<Map<String, Object>> filter(List<Map<String, Object>> dataRows, RowFilter filter) {
        return filter.filter(dataRows);
    }
    
    public List<List<Map<String, Object>>> getGroupedDataRows(Sheet sheet, List<ColumnDefinition> headers, int dataIdx, Set<String> columnKeys) {
        List<List<Map<String, Object>>>  groupData   = new ArrayList<List<Map<String, Object>>>();
        List<Map<String, Object>> dataRows = new ArrayList<Map<String, Object>>();
        for (Row row : sheet) {
            if (row.getRowNum() >= dataIdx) {
                if (!xLMapper.isRowEmpty(row)) {
                    dataRows.add(rowToMap(headers, row));
                }
            }
        }
        return groupData;
    }
    
    

    
    
    public HashMap<String, Object> rowToMap(List<ColumnDefinition> headers, Row row) {
        return xLMapper.rowToMap(headers, row);

    }

    public List<ColumnDefinition> mapColumns(List<ColumnDefinition> columns, Map<String, Integer> map) {
        for (ColumnDefinition columnDef : columns) {
            String srcName = columnDef.getSourceName();
            Integer idx = map.get(srcName);
            columnDef.setColumnIdx(idx);
        }
        return columns;
    }

    protected Object getCellValue(Cell cell) {
        return xLMapper.getCellValue(cell);
    }

}