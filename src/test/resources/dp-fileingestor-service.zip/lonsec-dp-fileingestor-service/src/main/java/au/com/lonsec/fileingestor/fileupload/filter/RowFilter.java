package au.com.lonsec.fileingestor.fileupload.filter;

import java.util.List;
import java.util.Map;

public interface RowFilter {

    List<Map<String, Object>> filter(List<Map<String, Object>> dataRows);

}