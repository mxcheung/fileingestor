package au.com.lonsec.fileingestor.fileupload;

public enum FileStatusType {

    STORED,
    QUEUED,
    PROCESSED,
    
}

