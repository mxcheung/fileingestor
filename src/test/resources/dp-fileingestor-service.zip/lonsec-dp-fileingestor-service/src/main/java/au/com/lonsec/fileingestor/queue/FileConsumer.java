package au.com.lonsec.fileingestor.queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import au.com.lonsec.fileingestor.fileupload.FileProcessorService;
import au.com.lonsec.fileingestor.fileupload.QueueItemEntity;

public class FileConsumer implements Runnable {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileConsumer.class);

    private final FileProcessorService fileProcessorService;

    private final FileIngestorQueueService fileIngestorQueueService;

    FileConsumer(FileProcessorService fileProcessorService, FileIngestorQueueService fileIngestorQueueService) {
        this.fileProcessorService = fileProcessorService;
        this.fileIngestorQueueService = fileIngestorQueueService;
    }

    public void run() {
        try {
            while (true) {
                consume();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public void consume() throws InterruptedException {
        QueueItemEntity item = fileIngestorQueueService.take();
        LOGGER.info("processing file id: {}", item.getFileId());
        fileProcessorService.processQItem(item);
    }

}
