package au.com.lonsec.fileingestor.validation.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import au.com.lonsec.fileingestor.fileupload.model.ValidationDTO;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "validationDTO", "validationRules" })
public class ValidationRequest {

    private ValidationDTO validationDTO;
    private List<ValidationRule> validationRules;

    @JsonCreator
    public ValidationRequest(@JsonProperty("validationDTO") ValidationDTO validationDTO,
            @JsonProperty("validationRules") List<ValidationRule> validationRules) {
        super();
        this.validationDTO = validationDTO;
        this.validationRules = validationRules;
    }

    public ValidationDTO getValidationDTO() {
        return validationDTO;
    }

    public void setValidationDTO(ValidationDTO validationDTO) {
        this.validationDTO = validationDTO;
    }

    public List<ValidationRule> getValidationRules() {
        return validationRules;
    }

    public void setValidationRules(List<ValidationRule> validationRules) {
        this.validationRules = validationRules;
    }

}
