package au.com.lonsec.fileingestor.validation.server;

/**
 * @author MAX see https://studio.restlet.com/apis/local/sections/Companies
 *         https://hello-angularjs.appspot.com/searchtable
 */
public final class ValidationURI {

    public static final String VALIDATION_BASE_CONTEXT = "/validation";

    public static final String POST_VALIDATE_MAPPING = "/validate";

    private ValidationURI() {
    }

}