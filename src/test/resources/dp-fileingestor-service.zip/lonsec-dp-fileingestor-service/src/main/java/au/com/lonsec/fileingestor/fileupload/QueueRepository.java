package au.com.lonsec.fileingestor.fileupload;

import org.springframework.data.jpa.repository.JpaRepository;

public interface QueueRepository extends JpaRepository<QueueItemEntity, Long> {

}