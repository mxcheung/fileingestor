package au.com.lonsec.fileingestor.filespec.server;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import au.com.lonsec.fileingestor.filespec.FileSpecService;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;

@RestController
@RequestMapping(value = FileSpecURI.FILESPEC_BASE_CONTEXT)
public class FileSpecController {

    @Autowired
    private FileSpecService fileSpecService;

    @RequestMapping(value = FileSpecURI.GET_REPORT_DEFINITION, method = GET)
    public ResponseEntity<ReportDefinition> getReportDefinition(
            @RequestParam(value = "name", required = false, defaultValue = "portfolioHoldingDef") String name,
            @RequestHeader(value = "Authorization", required = false) final String authToken) throws IOException {
        ReportDefinition result = fileSpecService.getReportDefinition(name);
        return new ResponseEntity<ReportDefinition>(result, HttpStatus.OK);

    }

}
