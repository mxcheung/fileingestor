package au.com.lonsec.fileingestor.fileexport.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * ExportQuestionnaireDTO Model representation for Export file request.
 * 
 * @author MCheung
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "questionnaires" })
public class ExportQuestionnaireDTO {

    private List<QuestionnaireDTO> questionnaires;

    public List<QuestionnaireDTO> getQuestionnaires() {
        return questionnaires;
    }

    public void setQuestionnaires(List<QuestionnaireDTO> questionnaires) {
        this.questionnaires = questionnaires;
    }
    
}
