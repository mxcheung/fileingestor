package au.com.lonsec.fileingestor.queue;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.springframework.stereotype.Service;

import au.com.lonsec.fileingestor.fileupload.QueueItemEntity;

@Service
public class FileIngestorQueueService {

    private BlockingQueue<QueueItemEntity> queue;

    public FileIngestorQueueService() {
        queue = new LinkedBlockingQueue<>();
    }

    public BlockingQueue<QueueItemEntity> getQueue() {
        return queue;
    }

    public void setQueue(BlockingQueue<QueueItemEntity> queue) {
        this.queue = queue;
    }

    public void put(QueueItemEntity item) throws InterruptedException {
        queue.put(item);
    }

    public QueueItemEntity take() throws InterruptedException {
        return queue.take();
    }

}
