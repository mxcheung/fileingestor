package au.com.lonsec.fileingestor.filespec;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.util.JSONHelper;

@Service
public class FileSpecService {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileSpecService.class);

    private final Map<String, String> filespecs;

    private Map<String, ReportDefinition> fileSpecsDefinitions;

    @Autowired
    public FileSpecService(FileSpecConfig templateConfig) {
        this.filespecs = templateConfig.getFilespecs();
        fileSpecsDefinitions = loadFileDefinition(filespecs);
    }

    /**
     * @param specs Map of fileuploadSpec and filepath.
     * @return Map of file definitions.
     */
    public Map<String, ReportDefinition> loadFileDefinition(Map<String, String> specs) {
        Map<String, ReportDefinition> fileDefinitions = new HashMap<String, ReportDefinition>();
        for (Entry<String, String> entry : specs.entrySet()) {
            String key = entry.getKey();
            String filePath = entry.getValue();

            try {
                ReportDefinition reportDefinition = loadReportDefinition(filePath);
                fileDefinitions.put(key, reportDefinition);
            } catch (Exception e) {
                LOGGER.error("Unable to load file spec: {}", filePath, e);
            }
        }
        return fileDefinitions;
    }

    public ReportDefinition getReportDefinition(String fileSpec) throws IOException {
        return fileSpecsDefinitions.get(fileSpec);
    }

    private ReportDefinition loadReportDefinition(String filePath) throws IOException {
        String json = getFileSpecJSON(filePath);
        ObjectMapper mapper = JSONHelper.getObjectMapper();
        ReportDefinition reportDefinition = mapper.readValue(json, ReportDefinition.class);
        return reportDefinition;
    }

    private String getFileSpecJSON(String filePath) throws IOException {
        URL url = FileSpecService.class.getClassLoader().getResource(filePath);
        File file = new File(URLDecoder.decode(url.getFile(), "UTF-8"));
        return FileUtils.readFileToString(file, StandardCharsets.UTF_8);
    }

}
