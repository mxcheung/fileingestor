package au.com.lonsec.fileingestor.fileupload.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.io.IOException;
import java.util.List;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DataSetDTOTest extends DataSetDTOTst  {


    private final static String JSON_STRING = "{\"dataSetName\":\"dataSetName\",\"sectionName\":\"sectionName\",\"totalRows\":0,\"errorRows\":0,\"dataRows\":[{\"rowNum\":1,\"data\":{\"securityName\":\"BOOZ ALLEN\",\"apirCd\":\"apirCd123\",\"absPortfolioWeight\":\"67\"},\"containsErrors\":false},{\"rowNum\":1,\"data\":{\"securityName\":\"BOOZ ALLEN\",\"apirCd\":\"apirCd123\",\"absPortfolioWeight\":\"67\"},\"containsErrors\":false}],\"containsErrors\":false}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
        dataSetDTO = getDataSetDTO();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        String json = this.mapper.writeValueAsString(dataSetDTO);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        dataSetDTO = mapper.readValue(JSON_STRING, DataSetDTO.class);
         List<ValidationDTO> data = dataSetDTO.getDataRows();
        assertEquals(2, data.size());
        assertFalse( dataSetDTO.isContainsErrors());
        assertEquals("sectionName", dataSetDTO.getDataSetName());
    }


}
