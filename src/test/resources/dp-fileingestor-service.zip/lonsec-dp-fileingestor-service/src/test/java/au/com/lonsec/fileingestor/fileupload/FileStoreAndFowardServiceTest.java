package au.com.lonsec.fileingestor.fileupload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.multipart.MultipartFile;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.fileupload.model.BatchDTO;
import au.com.lonsec.fileingestor.fileupload.model.FileDTO;
import au.com.lonsec.fileingestor.queue.FileProducer;

@RunWith(MockitoJUnitRunner.class)
public class FileStoreAndFowardServiceTest {

    private static final String QUEUED =  FileStatusType.QUEUED.name();
    private static final String STORED =  FileStatusType.STORED.name();

    private static final String MOCK_ORIG_FILENAME = "mockfile";

    @Mock
    private FileProcessorService mockfileProcessorService;

    @Mock
    private MultipartFile mockMultipartFile;

    @Mock
    private FileService fileService;

    @Mock
    private FileContentRepository fileContentRepository;

    @Mock
    private QueueRepository queueRepository;

    @Mock
    private BatchRepository batchRepository;

    @Mock
    private FileMapper fileMapper;

    @Mock
    private FileProducer fileProducer;

    private FileStoreAndFowardService fileStoreAndFowardService;

    @Before
    public void setup() throws IOException {
        fileStoreAndFowardService = new FileStoreAndFowardService(fileMapper, batchRepository, fileProducer,
                fileService, fileContentRepository);
        when(mockMultipartFile.getOriginalFilename()).thenReturn(MOCK_ORIG_FILENAME);
        when(mockMultipartFile.getBytes()).thenReturn(MOCK_ORIG_FILENAME.getBytes());
    }

    @Test
    public void shouldInitialiseService() {
        assertNotNull(fileStoreAndFowardService);
    }

    @Test
    public void shouldStoreSingleFile() throws IOException, InterruptedException {
        Long batchId = 1L;
        BatchEntity batchEntity = DomainStereotypeUtil.getBatchEntity();
        when(batchRepository.findOne(batchId)).thenReturn(batchEntity);
        FileEntity result = fileStoreAndFowardService.storeAndFwd(mockMultipartFile, batchId,true);
        assertEquals(batchId, result.getBatchId());
    }

    @Test
    public void shouldStoreMultipleFile() throws IOException, InterruptedException {
        MultipartFile[] mpFiles = new MultipartFile[1];
        mpFiles[0] = mockMultipartFile;
        Long batchId = 1L;
        BatchEntity batchEntity = DomainStereotypeUtil.getBatchEntity();
        when(batchRepository.findOne(batchId)).thenReturn(batchEntity);
        BatchDTO result = fileStoreAndFowardService.storeAndFwd(mpFiles, batchId,true);
        assertEquals(batchId, result.getId());
    }

    @Test
    public void shouldReturnFileStatus() throws IOException, InterruptedException {
        assertEquals(QUEUED, fileStoreAndFowardService.getFileStatus(true));
        assertEquals(STORED, fileStoreAndFowardService.getFileStatus(false));
    }
    
    @Test
    public void shouldCreateBatch() throws IOException, InterruptedException {
        Long batchId = 1L;
        BatchEntity batchEntity = DomainStereotypeUtil.getBatchEntity();
        when(batchRepository.save(any(BatchEntity.class))).thenReturn(batchEntity);
        BatchEntity result = fileStoreAndFowardService.findOrCreate(null);
        verify(batchRepository, times(1)).save(any(BatchEntity.class));
        verifyNoMoreInteractions(batchRepository);
        assertEquals(batchId, result.getId());
    }
    
    @Test
    public void shouldFindBatch() throws IOException, InterruptedException {
        Long batchId = 1L;
        BatchEntity batchEntity = DomainStereotypeUtil.getBatchEntity();
        when(batchRepository.findOne(batchId)).thenReturn(batchEntity);
        BatchEntity result = fileStoreAndFowardService.findOrCreate(batchId);
        assertEquals(batchId, result.getId());
    }

    @Test
    public void shouldConvertFileEntities() {
        List<FileEntity> fileEntitys = DomainStereotypeUtil.getFileEntities();
        FileDTO dest = DomainStereotypeUtil.getFileDTO();
        FileEntity source = fileEntitys.get(0);
        when(fileMapper.map(source, dest)).thenReturn(dest);
        List<FileDTO> result = fileStoreAndFowardService.convert(fileEntitys);
        assertEquals(1, result.size());
    }

}
