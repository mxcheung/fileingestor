package au.com.lonsec.fileingestor.fileexport.model;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;

public class ExportFileDTOTest extends ExportFileUploadTst  {


    private final static String JSON_STRING = "{\"questionId\":\"questionId\",\"batchIds\":[1]}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
        exportFileDTO = getExportFileDTO();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        String json = this.mapper.writeValueAsString(exportFileDTO);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        exportFileDTO = mapper.readValue(JSON_STRING, ExportFileDTO.class);
        assertEquals(DomainStereotypeUtil.QUESTION_ID,exportFileDTO.getQuestionId());
    }


}
