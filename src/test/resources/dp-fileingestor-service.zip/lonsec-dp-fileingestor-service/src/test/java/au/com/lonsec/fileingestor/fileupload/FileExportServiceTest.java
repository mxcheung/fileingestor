package au.com.lonsec.fileingestor.fileupload;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.fileexport.model.ExportFileDTO;
import au.com.lonsec.fileingestor.fileexport.model.ExportQuestionnaireDTO;
import au.com.lonsec.fileingestor.fileexport.model.QuestionnaireDTO;

@RunWith(MockitoJUnitRunner.class)
public class FileExportServiceTest {

    private FileExportService fileExportService;

    private FileEntity fileEntity;
    
    private List<FileEntity> fileEntities;

    @Mock
    private FileService fileService;
    
    @Mock
    private ZipOutputStream zipOutputStream;

    @Before
    public void setup() {
        fileExportService = new FileExportService(fileService);
        fileEntity = DomainStereotypeUtil.getFileEntity();
        fileEntities = DomainStereotypeUtil.getFileEntities();
    }

    @Test
    public void shouldCreateZipFileName() {
        String questionId = "Q123";
        String qfolder = "20170630Company";
        String zipFileName = fileExportService.getZipFileName(qfolder, questionId, fileEntity);
        assertEquals("20170630Company\\Q123_1_originalFileName", zipFileName);
    }

    @Test
    public void shouldExportFiles() throws IOException {
        ExportQuestionnaireDTO exportRequest = DomainStereotypeUtil.getExportQuestionnaireDTO();
        List<QuestionnaireDTO> questionnaires = exportRequest.getQuestionnaires();
        assertEquals(1, questionnaires.size());
        QuestionnaireDTO questinnaire = questionnaires.get(0);
        List<ExportFileDTO> files = questinnaire.getFiles();
        ExportFileDTO qfile = files.get(0);
        List<Long> batchIds = qfile.getBatchIds();
        when(fileService.findByBatchIds(batchIds)).thenReturn(fileEntities);
        fileExportService.exportFiles(exportRequest);
        verify(fileService, times(1)).findByBatchIds(batchIds);
        verifyNoMoreInteractions(fileService);
    }
    
    @Test
    public void shouldWriteZipFile() throws IOException {
        String questionId = "Q123";
        String qfolder = "20170630Company";
        fileExportService.writeZipFile(zipOutputStream,  qfolder, questionId, fileEntities);
        verify(zipOutputStream, times(1)).putNextEntry(any(ZipEntry.class));
        verify(zipOutputStream, times(1)).write(any(byte[].class));
        verify(zipOutputStream, times(1)).closeEntry();
        verifyNoMoreInteractions(zipOutputStream);
    }

    @Test
    public void shouldAddToZip() throws IOException {
        String questionId = "Q123";
        String qfolder = "20170630Company";
        fileExportService.addToZip(qfolder, questionId, fileEntity, zipOutputStream);
        verify(zipOutputStream, times(1)).putNextEntry(any(ZipEntry.class));
        verify(zipOutputStream, times(1)).write(any(byte[].class));
        verify(zipOutputStream, times(1)).closeEntry();
        verifyNoMoreInteractions(zipOutputStream);
    }

}
