package au.com.lonsec.fileingestor.filespec.model;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;

public class ColumnDefinitionTst {

    
    
    protected static final String SOURCE_NAME = "sourceName";

    protected ColumnDefinition getColumnDefinition() {
        return DomainStereotypeUtil.getColumnDefinition();
    }
    
    
}
