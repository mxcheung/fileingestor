package au.com.lonsec.fileingestor.validation.util;
import static org.junit.Assert.assertNotNull;

import java.lang.reflect.Method;

import org.junit.Test;


public class JuelFunctionsMockTest  {
    
    

	    @Test
	    public void testToUpper() {
	         Method upper =    SpelFunctions.getMethodSingleParam("toUpper");
	         assertNotNull(upper); 
	    }

	    @Test(expected = RuntimeException.class)
        public void testInvalidMethod() {
             Method upper =    SpelFunctions.getMethodSingleParam("toUpperxxx");
             assertNotNull(upper); 
        }
	    
	    @Test(expected = RuntimeException.class)
        public void testInvalidSecuritMethod() {
             Method upper =    SpelFunctions.getMethodSingleParam("toLowerX");
             assertNotNull(upper); 
        }
        
	    
	   
	    
}
