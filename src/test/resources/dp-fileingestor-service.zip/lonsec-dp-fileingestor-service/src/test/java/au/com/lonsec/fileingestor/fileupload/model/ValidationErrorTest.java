package au.com.lonsec.fileingestor.fileupload.model;


import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ValidationErrorTest extends ValidationErrorTst {

    private final static String JSON_STRING = "{\"fieldName\":\"fieldName\",\"message\":\"securityName  must be between 0 and 20 characters\",\"rowNum\":1,\"colNum\":1}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
    	ValidationError validationError = getValidationError();
        String json = this.mapper.writeValueAsString(validationError);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
    	ValidationError validationError = mapper.readValue(JSON_STRING, ValidationError.class);
        assertEquals(FIELD_NAME, validationError.getFieldName());
    }
    

    
}
