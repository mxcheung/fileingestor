package au.com.lonsec.fileingestor.util;
import static org.junit.Assert.assertEquals;
import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.junit.Before;
import org.junit.Test;
import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;

public class KeySetUtilTest  {


    @Before
    public void setup() {
    }
    
    @Test
    public void shouldGetSingleKey() throws IOException {
        Map<String, Object> row = DomainStereotypeUtil.getDataRow();
        Set<String> columnKeys = new HashSet<String>();
        columnKeys.add(DomainStereotypeUtil.APIR_CD);
        String result = KeySetUtil.getKey(row, columnKeys);
        assertEquals(row.get(DomainStereotypeUtil.APIR_CD), result);
    }

    @Test
    public void shouldGetCompositeKey() throws IOException {
        Map<String, Object> row = DomainStereotypeUtil.getDataRow();
        Set<String> columnKeys = new HashSet<String>();
        columnKeys.add(DomainStereotypeUtil.APIR_CD);
        columnKeys.add(DomainStereotypeUtil.SECURITY_NAME);
        String result = KeySetUtil.getKey(row, columnKeys);
        assertEquals("BOOZ ALLEN,apirCd123", result);
    }

}
