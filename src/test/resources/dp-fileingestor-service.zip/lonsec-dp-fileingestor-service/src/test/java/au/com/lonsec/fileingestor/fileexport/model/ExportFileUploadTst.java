package au.com.lonsec.fileingestor.fileexport.model;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;

public class ExportFileUploadTst {

    protected ExportFileDTO exportFileDTO;

    protected QuestionnaireDTO questionnaireDTO;

    protected ExportQuestionnaireDTO exportQuestionnaireDTO;

    protected ExportFileDTO getExportFileDTO() {
        return DomainStereotypeUtil.getExportFileDTO();
    }

    protected QuestionnaireDTO getQuestionnaireDTO() {
        return DomainStereotypeUtil.getQuestionnaireDTO();
    }

    protected ExportQuestionnaireDTO getExportQuestionnaireDTO() {
        return DomainStereotypeUtil.getExportQuestionnaireDTO();
    }

}
