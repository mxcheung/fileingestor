package au.com.lonsec.fileingestor.poi;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.junit.Before;
import org.junit.Test;

public class PoiServiceTest {

    private static final String XSSF_RESOURCE = "/xssf/test/FileSpecMap_gaps.xls";

    private InputStream excelFileToRead = getClass().getResourceAsStream(XSSF_RESOURCE);

    private PoiService xSSFDataService;
    private List<Sheet> wbData;

    @Before
    public void setup() throws Exception {
        xSSFDataService = new PoiService();
        wbData = xSSFDataService.extractSheets(excelFileToRead, "xls");
    }

    @Test
    public void testEquityWorkSheet() throws IOException, OpenXML4JException {
        assertEquals(4, wbData.size());
        Sheet sheet = wbData.get(0);
        Row row = xSSFDataService.getRow(sheet, 1);
        assertEquals(0, row.getFirstCellNum());
        assertEquals("Equity", sheet.getSheetName());
    }

    @Test
    public void testRowToMap() throws IOException, OpenXML4JException {
        assertEquals(4, wbData.size());
        Sheet sheet = wbData.get(0);
        Row row = xSSFDataService.getRow(sheet, 1);
        Map<String, Integer> map = xSSFDataService.getRowToHeadersMap(row);
        assertEquals(1, map.size());
        map = xSSFDataService.getRowToHeadersMap(null);
        assertEquals(0, map.size());
    }

}
