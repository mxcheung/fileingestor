package au.com.lonsec.fileingestor.fileupload.validator;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.filespec.FileSpecConfig;
import au.com.lonsec.fileingestor.filespec.FileSpecService;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.FileSpecNotFoundException;
import au.com.lonsec.fileingestor.poi.PoiService;

@RunWith(MockitoJUnitRunner.class)
public class SheetConfigTest {

    private SheetConfig sheetConfig;

    @Mock
    FileSpecConfig config;

    @Mock
    private SectionValidator sectionValidator;

    @Mock
    private RowValidator rowValidator;

    private PoiService poiService;

    @Mock
    private Sheet sheet;
    
    @Mock
    private FileSpecService fileSpecService;

    private Map<String, String> filespecs;

    private ReportDefinition reportDefinition;

    private static final String XSSF_RESOURCE = "/xssf/test/FileSpecMap_gaps.xls";

    private static final String XSSF_MISSING_FILESPEC_RESOURCE = "/xssf/test/MissingFileSpecWith_gaps.xls";

    private InputStream excelFileToRead = getClass().getResourceAsStream(XSSF_RESOURCE);

    @Before
    public void setup() {
        filespecs = new HashMap<String, String>();
        filespecs.put("portfolioHoldingDef", "filespec/portfolioHoldingDef.json");
        when(config.getFilespecs()).thenReturn(filespecs);
        sheetConfig = new SheetConfig(fileSpecService);
        reportDefinition = DomainStereotypeUtil.getReportDefinition();
        poiService = new PoiService();
        excelFileToRead = getClass().getResourceAsStream(XSSF_RESOURCE);

    }

    @Test
    public void shouldLoadConfig() throws InvalidFormatException, IOException {
        List<Sheet> wbData = poiService.extractSheets(excelFileToRead, "xls");
        assertEquals(4, wbData.size());
        Sheet mappingSheet = wbData.get(1);
        assertEquals("Mapping", mappingSheet.getSheetName());
        assertEquals(2, reportDefinition.getDataStartRow());
        sheetConfig.loadConfig(reportDefinition, mappingSheet);
        assertEquals(2, reportDefinition.getDataStartRow());
    }

    @Test
    public void shouldOverrideSystem() throws InvalidFormatException, IOException {
        List<Sheet> wbData = poiService.extractSheets(excelFileToRead, "xls");
        assertEquals(4, wbData.size());
        Map<String, Object> systemMap = new HashMap<String, Object>();
        systemMap.put("headerStartRow", 1);
        systemMap.put("dataStartRow", 3);
        assertEquals(2, reportDefinition.getDataStartRow());
        sheetConfig.overrideSystem(reportDefinition, systemMap);
        assertEquals(3, reportDefinition.getDataStartRow());
    }
    
    @Test(expected = FileSpecNotFoundException.class)
    public void shouldGetFileSpecException() throws InvalidFormatException, IOException, FileSpecNotFoundException {
    	excelFileToRead = getClass().getResourceAsStream(XSSF_MISSING_FILESPEC_RESOURCE);
        List<Sheet> wbData = poiService.extractSheets(excelFileToRead, "xls");
        assertEquals(4, wbData.size());
        Sheet mappingSheet = wbData.get(1);
        assertEquals("Mapping", mappingSheet.getSheetName());
        sheetConfig.getFileSpec( mappingSheet);
    }
    
    @Test
    public void shouldGetFileSpec() throws InvalidFormatException, IOException, FileSpecNotFoundException {
    	excelFileToRead = getClass().getResourceAsStream(XSSF_RESOURCE);
    	List<Sheet> wbData = poiService.extractSheets(excelFileToRead, "xls");
        assertEquals(4, wbData.size());
        Sheet mappingSheet = wbData.get(1);
        assertEquals("Mapping", mappingSheet.getSheetName());
        String fileSpec = sheetConfig.getFileSpec( mappingSheet);
        assertEquals("portfolioHoldingDef", fileSpec);
    }

}
