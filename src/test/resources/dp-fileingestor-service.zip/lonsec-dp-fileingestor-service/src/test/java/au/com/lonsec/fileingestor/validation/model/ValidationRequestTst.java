package au.com.lonsec.fileingestor.validation.model;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.fileupload.model.ValidationDTO;
import au.com.lonsec.fileingestor.util.JSONHelper;

public class ValidationRequestTst {
    
    protected static final String APIR_CD = "apirCd";
    
    protected ObjectMapper getObjectMapper() {
        return JSONHelper.getObjectMapper();
    }

    protected ValidationRequest getValidationRequest() {
    	return DomainStereotypeUtil.getValidationRequest();
    }

    protected ValidationDTO getHolding() {
    	return DomainStereotypeUtil.getHolding();
    }
    
    protected ValidationRule getValidationRule() {
    	return DomainStereotypeUtil.getValidationRule();
    }

    protected ValidationRule getSecurityNameValidationRule() {
    	return DomainStereotypeUtil.getSecurityNameValidationRule();
    }
    
    protected ValidationRule getISINValidationRule() {
    	return DomainStereotypeUtil.getISINValidationRule();
    }
    
    

}
