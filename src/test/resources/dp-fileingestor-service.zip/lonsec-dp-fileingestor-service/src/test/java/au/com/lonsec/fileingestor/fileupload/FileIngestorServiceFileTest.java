package au.com.lonsec.fileingestor.fileupload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import au.com.lonsec.fileingestor.filespec.FileSpecService;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.DataSetDTO;
import au.com.lonsec.fileingestor.poi.PoiService;
import au.com.lonsec.fileingestor.poi.RowMapper;

@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest()
@ActiveProfiles("local")
public class FileIngestorServiceFileTest {

    private static final String APIR_CODE_OR_TICKER = "APIR CODE(or Ticker)";

    private InputStream excelFileToRead;

    @Autowired
    private FileIngestorService fileIngestorService;
    
    @Autowired
    private FileSpecService fileSpecService;

    @Autowired
    private FileProcessorService fileProcessorService;

    @Autowired
    private PoiService poiService;

    @Before
    public void setup() throws IOException {
        assertNotNull(fileIngestorService);
    }

    @Ignore
    @Test
    public void shouldLoadBlackRockSummaryHolding() throws IOException, InvalidFormatException {
        excelFileToRead = getClass().getResourceAsStream("/xssf/blackrock/Lonsec_HoldingsSummary.m.20171031.xlsx");
        ReportDefinition reportDefinition = fileSpecService.getReportDefinition("blackrock_HoldingsSummaryDef");
        List<Sheet> sheets = poiService.extractSheets(excelFileToRead, "xlsx");
        assertEquals(3, sheets.size());
        List<DataSetDTO> result = fileProcessorService.processSheets(reportDefinition, sheets);
        assertEquals(25, result.size());
    }

    
    @Test
    public void shouldLoadLonsecEquityHolding() throws IOException, InvalidFormatException {
        excelFileToRead = getClass().getResourceAsStream("/xssf/lonsec/Holding Equity 456_20171106012756_with_gaps.xls");
        ReportDefinition reportDefinition = fileSpecService.getReportDefinition("portfolioHoldingDef");
        List<Sheet> sheets = poiService.extractSheets(excelFileToRead,"xls");
        assertEquals(4, sheets.size());
        List<DataSetDTO> result = fileProcessorService.processSheets(reportDefinition, sheets);
        assertEquals(1, result.size());
        DataSetDTO dataSetDTO = result.get(0);
        assertEquals("Equity", dataSetDTO.getSheetName());
        assertEquals(723, dataSetDTO.getTotalRows());
        assertEquals(178, dataSetDTO.getErrorRows());

    }

    @Test
    public void shouldLoadLonsecFixedIncomeHolding() throws IOException, InvalidFormatException {
        excelFileToRead = getClass().getResourceAsStream("/xssf/lonsec/Holding FI 453_20171030051226.xlsx");
        ReportDefinition reportDefinition = fileSpecService.getReportDefinition("fixedIncomeHoldingDef");
        List<Sheet> sheets = poiService.extractSheets(excelFileToRead,"xlsx");
        assertEquals(1, sheets.size());
        List<DataSetDTO> result = fileProcessorService.processSheets(reportDefinition, sheets);
        assertEquals(1, result.size());
        DataSetDTO dataSetDTO = result.get(0);
        assertEquals("FI Holdings", dataSetDTO.getSheetName());
        assertEquals(525, dataSetDTO.getTotalRows());
        assertEquals(2, dataSetDTO.getErrorRows());
    }

    
    @Test
    public void shouldLoadLonsecMultiAssetHolding() throws IOException, InvalidFormatException {
        excelFileToRead = getClass().getResourceAsStream("/xssf/lonsec/Holding MA 182_20171023014212.xlsx");
        ReportDefinition reportDefinition = fileSpecService.getReportDefinition("multiAssetHoldingDef");
        List<Sheet> sheets = poiService.extractSheets(excelFileToRead,"xlsx");
        assertEquals(2, sheets.size());
        List<DataSetDTO> result = fileProcessorService.processSheets(reportDefinition, sheets);
        assertEquals(2, result.size());
        DataSetDTO dataSetDTO = result.get(0);
        assertEquals("MAIF", dataSetDTO.getSheetName());
        assertEquals(196, dataSetDTO.getTotalRows());
        assertEquals(2, dataSetDTO.getErrorRows());
        dataSetDTO = result.get(1);
        assertEquals("MARRF", dataSetDTO.getSheetName());
        assertEquals(627, dataSetDTO.getTotalRows());
        assertEquals(2, dataSetDTO.getErrorRows());
    }

    @Test
    public void shouldLoadMLCHolding() throws IOException, InvalidFormatException  {
        excelFileToRead = getClass().getResourceAsStream("/xssf/mlc/Holding Data Effective Exposure - MLCIT 30092017.xls");
        ReportDefinition reportDefinition = fileSpecService.getReportDefinition("mlc_HoldingsSummaryDef");
        assertNotNull(reportDefinition);
        List<Sheet> sheets = poiService.extractSheets(excelFileToRead,"xls");
        assertEquals(20, sheets.size());
        List<DataSetDTO> result = fileProcessorService.processSheets(reportDefinition, sheets);
        assertEquals(18, result.size());
        DataSetDTO dataSetDTO = result.get(0);
        assertEquals("Aust Share", dataSetDTO.getSheetName());
        assertEquals(97, dataSetDTO.getTotalRows());
        assertEquals(1, dataSetDTO.getErrorRows());
    }    

    
    @Test
    public void shouldLoadMorningStarSummaryHolding() throws IOException, InvalidFormatException {
        excelFileToRead = getClass().getResourceAsStream("/xssf/morningstar/Morningstar-CFS (8bd4b120-4c7c-49b1-988a-8ba9a259c109).xlsx");
        ReportDefinition reportDefinition = fileSpecService.getReportDefinition("morningstar_HoldingsSummaryDef");
        List<Sheet> sheets = poiService.extractSheets(excelFileToRead,"xlsx");
        assertEquals(1, sheets.size());
        Sheet sheet = sheets.get(0);
        assertEquals("Holdings", sheet.getSheetName());
        RowMapper xLMapper = new RowMapper();
        Row row1 = poiService.getRow(sheet, 8);
        Row row2 = poiService.getRow(sheet, 9);
        String cellVal1 = (String) xLMapper.getCellValue(row1.getCell(1));
        String cellVal2 = (String) xLMapper.getCellValue(row2.getCell(1));
        String cellVal3 = cellVal1 + cellVal2;
        assertEquals(APIR_CODE_OR_TICKER, cellVal3);
        List<Cell> cells = new ArrayList<Cell>();
        cells.add(row1.getCell(1));
        cells.add(row2.getCell(1));
        RowMapper rowMapper = new RowMapper();
        String cellValue = rowMapper.getCellRangeText(cells);
        assertEquals(APIR_CODE_OR_TICKER, cellValue);
        List<DataSetDTO> result = fileProcessorService.processSheets(reportDefinition, sheets);
        assertEquals(1, result.size());
        DataSetDTO dataSetDTO = result.get(0);
        assertEquals("Holdings", dataSetDTO.getSheetName());
        assertEquals(3586, dataSetDTO.getTotalRows());
        assertEquals(1, dataSetDTO.getErrorRows());
    }

    
    @Test
    public void shouldLoadPerpetualHolding() throws IOException, InvalidFormatException {
        excelFileToRead = getClass().getResourceAsStream("/xssf/perpetual/Holdings July 2017 (PER0752AU).xlsx");
        ReportDefinition reportDefinition = fileSpecService.getReportDefinition("perpertual_HoldingsSummaryDef");
        List<Sheet> sheets = poiService.extractSheets(excelFileToRead,"xlsx");
        assertEquals(1, sheets.size());
        List<DataSetDTO> result = fileProcessorService.processSheets(reportDefinition, sheets);
        assertEquals(1, result.size());
        DataSetDTO dataSetDTO = result.get(0);
        assertEquals("PER0752AU", dataSetDTO.getSheetName());
        assertEquals(45, dataSetDTO.getTotalRows());
        assertEquals(20, dataSetDTO.getErrorRows());
    }
    

    @Test
    public void shouldLoadPimcoHolding() throws IOException, InvalidFormatException {
        excelFileToRead = getClass().getResourceAsStream("/xssf/pimco/PIMCO AUS - Australian Bond Fund Portfolio Holdings 1203.xls");
        ReportDefinition reportDefinition = fileSpecService.getReportDefinition("pimco_HoldingsSummaryDef");
        assertNotNull(reportDefinition);
        List<Sheet> sheets = poiService.extractSheets(excelFileToRead,"xls");
        assertEquals(1, sheets.size());
    }
    
    
    @Ignore
    @Test
    public void shouldLoadVanguardHolding() throws IOException, InvalidFormatException {
        excelFileToRead = getClass().getResourceAsStream("/xssf/vanguard/2017-10 Holdings (Funds and ETFs).xlsx");
        ReportDefinition reportDefinition = fileSpecService.getReportDefinition("vanguard_HoldingsSummaryDef");
        assertNotNull(reportDefinition);
        List<Sheet> sheets = poiService.extractSheets(excelFileToRead,"xlsx");
        assertEquals(40, sheets.size());
        List<DataSetDTO> result = fileProcessorService.processSheets(reportDefinition, sheets);
        assertEquals(39, result.size());
        DataSetDTO dataSetDTO = result.get(0);
        assertEquals("VACF (VACF)", dataSetDTO.getSheetName());
        assertEquals(331, dataSetDTO.getTotalRows());
        assertEquals(0, dataSetDTO.getErrorRows());
        dataSetDTO = result.get(1);
        assertEquals("VACFIIF (VAN0065AU)", dataSetDTO.getSheetName());
        assertEquals(330, dataSetDTO.getTotalRows());
        assertEquals(0, dataSetDTO.getErrorRows());
    }
    
    
}
