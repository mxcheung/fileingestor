package au.com.lonsec.fileingestor.fileexport.model;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ExportQuestionnaireDTOTest extends ExportFileUploadTst  {


    private final static String JSON_STRING = "{\"questionnaires\":[{\"questionnaireName\":\"questionnaireName\",\"files\":[{\"questionId\":\"questionId\",\"batchIds\":[1]}]}]}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
        exportQuestionnaireDTO = getExportQuestionnaireDTO();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        String json = this.mapper.writeValueAsString(exportQuestionnaireDTO);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        exportQuestionnaireDTO = mapper.readValue(JSON_STRING, ExportQuestionnaireDTO.class);
        assertEquals(1,exportQuestionnaireDTO.getQuestionnaires().size());
    }


}
