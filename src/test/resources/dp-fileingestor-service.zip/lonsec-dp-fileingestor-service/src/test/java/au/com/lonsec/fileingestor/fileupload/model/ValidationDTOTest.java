package au.com.lonsec.fileingestor.fileupload.model;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Map;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ValidationDTOTest extends ValidationDTOTst  {


    private final static String JSON_STRING = "{\"rowNum\":1,\"data\":{\"securityName\":\"BOOZ ALLEN\",\"apirCd\":\"apirCd123\",\"absPortfolioWeight\":\"67\"},\"containsErrors\":false}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        ValidationDTO holding = getValidationDTO();
        String json = this.mapper.writeValueAsString(holding);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        ValidationDTO holding = mapper.readValue(JSON_STRING, ValidationDTO.class);
        Map<String, Object> data = holding.getData();
        assertEquals("apirCd123", data.get(APIR_CD));
    }


}
