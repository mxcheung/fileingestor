package au.com.lonsec.fileingestor.queue;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.fileingestor.fileupload.FileProcessorService;
import au.com.lonsec.fileingestor.fileupload.QueueItemEntity;

@RunWith(MockitoJUnitRunner.class)
public class FileConsumerTest {

    private static final int BOUND = 10;

    @Mock
    private FileProcessorService  fileProcessorService;

    @Mock
    private FileIngestorQueueService fileIngestorQueueService;

    private FileConsumer fileConsumer;

    private final BlockingQueue<QueueItemEntity> queue = new LinkedBlockingQueue<>(BOUND);

    @Mock
    private BlockingQueue<QueueItemEntity> mockQueue;

    @Before
    public void setup() {
        fileConsumer = new FileConsumer(fileProcessorService, fileIngestorQueueService);
    }

    @Ignore
    @Test
    public void shouldConsumeQueueItem() throws InterruptedException {
        QueueItemEntity queueItemEntity = new QueueItemEntity();
        Long fileId = 1L;
        queueItemEntity.setFileId(fileId);
        queue.put(queueItemEntity);
        when(fileIngestorQueueService.take()).thenReturn(queueItemEntity);
        fileConsumer.consume();
        verify(fileProcessorService, times(1)).processItem(queueItemEntity);
        verifyNoMoreInteractions(fileProcessorService);

    }

    @Test
    public void shouldRunAsThread() throws InterruptedException {
        Thread thread = new Thread(fileConsumer);
        thread.start();
        assertTrue(thread.isAlive());
        thread.interrupt();
    }

    @Test
    public void shouldRun() throws InterruptedException {
        QueueItemEntity queueItemEntity = new QueueItemEntity();
        Long fileId = 1L;
        queueItemEntity.setFileId(fileId);
        when(fileIngestorQueueService.take()).thenReturn(queueItemEntity)
        .thenReturn(queueItemEntity)
        .thenThrow(new InterruptedException());
        fileConsumer.run();
        verify(fileIngestorQueueService, times(3)).take();
        verifyNoMoreInteractions(fileIngestorQueueService);
    }

    @Test
    public void shouldGetInterupted() throws InterruptedException {
        fileConsumer = new FileConsumer(fileProcessorService, fileIngestorQueueService);
        doThrow(new InterruptedException()).when(fileIngestorQueueService).take();
        fileConsumer.run();
        verify(fileIngestorQueueService, times(1)).take();
        verifyNoMoreInteractions(fileIngestorQueueService);

    }

}
