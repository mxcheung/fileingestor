package au.com.lonsec.fileingestor.filespec.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import au.com.lonsec.fileingestor.filespec.FileSpecConfig;
import au.com.lonsec.fileingestor.filespec.FileSpecService;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;

@RunWith(MockitoJUnitRunner.class)
public class FileSpecServiceTest {

	private FileSpecService service;

	@Mock
	FileSpecConfig config;

	private Map<String, String> filespecs;

	@Before
	public void setup() {
		filespecs = new HashMap<String, String>();
		filespecs.put("portfolioHoldingDef", "filespec/portfolioHoldingDef.json");
		when(config.getFilespecs()).thenReturn(filespecs);
		service = new FileSpecService(config);
	}

	@Test
	public void shouldReturnReportDefinition()
			throws JSONException, JsonParseException, JsonMappingException, IOException {
		String filePath = "portfolioHoldingDef";
		ReportDefinition reportDefinition = service.getReportDefinition(filePath);
		assertEquals(7, reportDefinition.getDataStartRow());
	}

	@Test
	public void shouldSkipInvalidEntry() throws JSONException, JsonParseException, JsonMappingException, IOException {
		filespecs = new HashMap<String, String>();
		filespecs.put("portfolioHoldingDef", "filespec/portfolioHoldingDef.json");
		filespecs.put("portfolioHoldingDefX", "filespec/xxxxportfolioHoldingDef.json");
		when(config.getFilespecs()).thenReturn(filespecs);
		this.service = new FileSpecService(config);
		Map<String, ReportDefinition> reportDefinitionMap = service.loadFileDefinition(filespecs);
		assertEquals(1, reportDefinitionMap.size());
	}

}
