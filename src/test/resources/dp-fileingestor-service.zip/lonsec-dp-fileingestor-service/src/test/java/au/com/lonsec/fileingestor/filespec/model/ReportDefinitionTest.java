package au.com.lonsec.fileingestor.filespec.model;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ReportDefinitionTest extends ReportDefinitionTst {

    private final static String JSON_STRING = "{\"headerStartRow\":1,\"dataStartRow\":2,\"columnDefinitions\":[{\"sourceName\":\"APIR Code\",\"targetName\":\"apirCd\"},{\"sourceName\":\"Fund Name\",\"targetName\":\"fundName\"},{\"sourceName\":\"SEDOL\",\"targetName\":\"sedol\"},{\"sourceName\":\"Security Name\",\"targetName\":\"securityName\"},{\"sourceName\":\"Absolute Portfolio Weight (%)\",\"targetName\":\"absPortfolioWeight\"},{\"sourceName\":\"Relative Portfolio Weight (%)\",\"targetName\":\"relPortfolioWeight\"},{\"sourceName\":\"Holding Date\",\"targetName\":\"holdingDate\"}],\"validationRules\":[{\"key\":\"apirCd\",\"expression\":\"apirCd.length() > 9\",\"message\":\"apirCd  must be between 0 and 9 characters\"},{\"key\":\"securityName\",\"expression\":\"securityName.length() > 20 \",\"message\":\"securityName  must be between 0 and 20 characters\"},{\"key\":\"#isin\",\"expression\":\"#isValidISIN(#isin)\",\"message\":\"isin  ${validatedValue}  check digit is invalid\"}]}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        ReportDefinition reportDefinition = getReportDefinition();
        String json = this.mapper.writeValueAsString(reportDefinition);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        ReportDefinition reportDefinition = mapper.readValue(JSON_STRING, ReportDefinition.class);
        assertEquals(7, reportDefinition.getColumnDefinitions().size());
        ColumnDefinition columnDefinition = reportDefinition.getColumnDefinitions().get(0);
        assertEquals(APIR_CODE, columnDefinition.getTargetName());
    }
    
    @Test
    public void shouldDeserializeFileSpec() throws IOException {
        String json = getFileSpecJSON();
        ReportDefinition reportDefinition = mapper.readValue(json, ReportDefinition.class);
        assertEquals(8, reportDefinition.getColumnDefinitions().size());
    }
    
    
}
