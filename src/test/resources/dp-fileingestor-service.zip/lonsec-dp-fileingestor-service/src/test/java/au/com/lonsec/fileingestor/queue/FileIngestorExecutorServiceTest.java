package au.com.lonsec.fileingestor.queue;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doThrow;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.context.event.ApplicationReadyEvent;

import au.com.lonsec.fileingestor.fileupload.FileProcessorService;
import au.com.lonsec.fileingestor.fileupload.QueueRepository;

@RunWith(MockitoJUnitRunner.class)
public class FileIngestorExecutorServiceTest {

	@Mock
	private FileProcessorService fileProcessorService;

	@Mock
	QueueRepository queueRepository;

	@Mock
	private FileProducer fileProducer;

	@Mock
	private FileIngestorQueueService fileIngestorQueueService;

	@Mock
	private ApplicationReadyEvent event;

	private FileIngestorExecutorService fileIngestorExecutorService;

	@Before
	public void setup() {
		fileIngestorExecutorService = new FileIngestorExecutorService(fileProcessorService, queueRepository,
				fileProducer, fileIngestorQueueService);
	}

	@Test
	public void shouldCreateConsumers() throws InterruptedException {
		fileIngestorExecutorService.createConsumers();
		assertEquals(1, fileIngestorExecutorService.getConsumers().size());
	}

	@Test()
	public void shouldInitialiseOnStartup() throws InterruptedException {
		fileIngestorExecutorService.onApplicationEvent(event);
	}

	@Test()
	public void shouldHandleInterruptedExceptionOnStartup() throws InterruptedException {
		doThrow(new InterruptedException()).when(fileProducer).recoverJobs();
		fileIngestorExecutorService.onApplicationEvent(event);
	}

	@Test
	public void shouldInitialise() throws InterruptedException {
		fileIngestorExecutorService.initialise();
		assertEquals(1, fileIngestorExecutorService.getConsumers().size());
	}

	@Test(expected = InterruptedException.class)
	public void shouldRaiseInterruptException() throws InterruptedException {
		doThrow(new InterruptedException()).when(fileProducer).recoverJobs();
		fileIngestorExecutorService.initialise();
	}

}
