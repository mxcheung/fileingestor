package au.com.lonsec.fileingestor.fileupload.filter;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

public class KeySetRowFilterTest {

    private static final String APIR_CD = "apirCd";
    private KeySetRowFilter keySetRowFilter;

    private List<Map<String, Object>> dataRows;

    @Before
    public void setup() {
        Set<String> keySet = new HashSet<String>();
        keySet.add(APIR_CD);
        keySetRowFilter = new KeySetRowFilter(keySet);
        dataRows = getDataRows();
    }

    @Test
    public void shouldFilterBlankRows() {
        assertEquals(2, dataRows.size());
        dataRows = keySetRowFilter.filter(dataRows);
        assertEquals(1, dataRows.size());
    }

    private List<Map<String, Object>> getDataRows() {
        List<Map<String, Object>> dataRows = new ArrayList<Map<String, Object>>();
        dataRows.add(getDataRow("BMIFAS", "", "", ""));
        dataRows.add(getDataRow("BAR0814AU", "BlackRock Scientific Australian Equity Fund", "0.12", "0.45"));
        return dataRows;
    }

    public static Map<String, Object> getDataRow(String apirCd, String securityName, String absPortfolioWeight, String relPortfolioWeight) {
        Map<String, Object> dataRow = new HashMap<String, Object>();
        dataRow.put(APIR_CD, apirCd);
        dataRow.put("securityName", securityName);
        dataRow.put("absPortfolioWeight", absPortfolioWeight);
        dataRow.put("relPortfolioWeight", relPortfolioWeight);
        return dataRow;
    }

}
