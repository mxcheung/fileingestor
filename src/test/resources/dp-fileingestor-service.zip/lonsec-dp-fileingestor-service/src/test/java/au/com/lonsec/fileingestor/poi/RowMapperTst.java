package au.com.lonsec.fileingestor.poi;


import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
public class RowMapperTst {

    protected static final String XSSF_RESOURCE = "/poi/hssf/RowTest.xls";
    protected RowMapper rowMapper;
    

    protected Row row;
    
    protected Sheet sheet;

    protected PoiService poiService;

    protected InputStream excelFileToRead = getClass().getResourceAsStream(XSSF_RESOURCE);

    protected Sheet getXLSSheet() throws InvalidFormatException, IOException {
        
        poiService = new PoiService();
        excelFileToRead = getClass().getResourceAsStream(XSSF_RESOURCE);

        List<Sheet> wbData = poiService.extractSheets(excelFileToRead,"xls");
        return wbData.get(0);
    }

    protected Row getXlsRow(int rowIndex) throws InvalidFormatException, IOException {
        Row row = poiService.getRow(sheet, rowIndex);
        return row;
    }

}
