package au.com.lonsec.fileingestor.fileupload.model;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;

public class ValidationErrorTst {
	
	protected static final String FIELD_NAME = "fieldName";

	protected ValidationError getValidationError() {
        return DomainStereotypeUtil.getValidationError();
    }
    
	
}
