package au.com.lonsec.fileingestor.fileupload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.filespec.FileSpecConfig;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.BatchDTO;
import au.com.lonsec.fileingestor.fileupload.model.FileDTO;
import au.com.lonsec.fileingestor.fileupload.model.ResultDTO;

@RunWith(MockitoJUnitRunner.class)
public class FileIngestorServiceTest {

    private static final String QUEUED =  FileStatusType.QUEUED.name();
    private static final String PROCESSED =  FileStatusType.PROCESSED.name();

    private static final String MOCK_ORIG_FILENAME = "mockfile";

    private FileIngestorService fileIngestorService;

    @Mock
    private FileSpecConfig config;

    @Mock
    private FileProcessorService mockfileProcessorService;

    @Mock
    private ReportDefinition mockReportDefinition;

    @Mock
    private MultipartFile mockMultipartFile;

    @Mock
    private FileService fileService;

    @Mock
    private FileContentRepository fileContentRepository;

    @Mock
    private BatchRepository batchRepository;

    @Mock
    private FileMapper fileMapper;

    private FileEntity fileEntity;

    @Before
    public void setup() throws IOException {
        fileIngestorService = new FileIngestorService(mockfileProcessorService, fileService, fileContentRepository, batchRepository, fileMapper);
        when(mockMultipartFile.getOriginalFilename()).thenReturn(MOCK_ORIG_FILENAME);
        fileEntity = DomainStereotypeUtil.getFileEntity();
    }

    @Test
    public void shouldImportData() throws IOException, OpenXML4JException {
        ResultDTO resultDTO = DomainStereotypeUtil.getResultDTO();
        when(mockfileProcessorService.importData(any(MultipartFile.class), any(String.class))).thenReturn(resultDTO);
        ResultDTO actual = fileIngestorService.importData(mockMultipartFile, "");
        assertEquals(resultDTO, actual);
    }

    @Test
    public void shouldGetBatchSummaryByBatchId() {
        BatchEntity batchEntity = DomainStereotypeUtil.getBatchEntity();
        FileDTO fileDTO = DomainStereotypeUtil.getFileDTO();
        List<FileEntity> fileEntitys = DomainStereotypeUtil.getFileEntities();
        Long batchId = batchEntity.getId();
        when(batchRepository.findOne(batchId)).thenReturn(batchEntity);
        when(fileService.findByBatchId(batchId)).thenReturn(fileEntitys);
        when(fileMapper.map(any(FileEntity.class), any(FileDTO.class))).thenReturn(fileDTO);
        BatchDTO result = fileIngestorService.getBatchSummary(batchId);
        assertEquals(result.getId(), batchEntity.getId());
        assertEquals(1, result.getFiles().size());
    }

    @Test
    public void shouldGetBatchStatus() {
        List<FileDTO> fileDTOs = DomainStereotypeUtil.getFileDTOs();
        assertEquals(1, fileDTOs.size());
        assertEquals(QUEUED, fileIngestorService.getBatchStatus(fileDTOs));
        fileDTOs.get(0).setStatus(PROCESSED);
        assertEquals(PROCESSED, fileIngestorService.getBatchStatus(fileDTOs));
    }

    @Test
    public void shouldGetBatchSummary() {
        BatchEntity batchEntity = DomainStereotypeUtil.getBatchEntity();
        List<FileDTO> fileDTOs = DomainStereotypeUtil.getFileDTOs();
        when(mockfileProcessorService.getLastProcessedFileEntity()).thenReturn(fileEntity);
        BatchDTO result = fileIngestorService.getBatchSummary(batchEntity, fileDTOs);
        assertEquals(result.getBatchFileId(), batchEntity.getId());
        assertEquals(1, result.getFiles().size());
    }

    @Test
    public void shouldFileErrors() throws JsonParseException, JsonMappingException, IOException {
        FileEntity fileEntity = DomainStereotypeUtil.getFileEntity();
        Long fileId = 1L;
        when(fileService.fetchFileEntity(fileId)).thenReturn(fileEntity);
        FileDTO fileDTO = fileIngestorService.getFileErrors(fileId);
        assertEquals(1, fileDTO.getTotalDatasets());
    }

}
