package au.com.lonsec.fileingestor.domain;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import au.com.lonsec.fileingestor.fileexport.model.ExportFileDTO;
import au.com.lonsec.fileingestor.fileexport.model.ExportQuestionnaireDTO;
import au.com.lonsec.fileingestor.fileexport.model.QuestionnaireDTO;
import au.com.lonsec.fileingestor.filespec.model.ColumnDefinition;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.BatchEntity;
import au.com.lonsec.fileingestor.fileupload.FileContentEntity;
import au.com.lonsec.fileingestor.fileupload.FileEntity;
import au.com.lonsec.fileingestor.fileupload.QueueItemEntity;
import au.com.lonsec.fileingestor.fileupload.model.BatchDTO;
import au.com.lonsec.fileingestor.fileupload.model.DataSetDTO;
import au.com.lonsec.fileingestor.fileupload.model.FileDTO;
import au.com.lonsec.fileingestor.fileupload.model.ResultDTO;
import au.com.lonsec.fileingestor.fileupload.model.SectionDTO;
import au.com.lonsec.fileingestor.fileupload.model.ValidationDTO;
import au.com.lonsec.fileingestor.fileupload.model.ValidationError;
import au.com.lonsec.fileingestor.util.FileUtil;
import au.com.lonsec.fileingestor.validation.model.ValidationRequest;
import au.com.lonsec.fileingestor.validation.model.ValidationRule;

public final class DomainStereotypeUtil {

    public static final String QUESTIONNAIRE_NAME = "questionnaireName";
    public static final String QUESTION_ID = "questionId";
    public static final Long QUEUE_ITEM_ID = 1L;
    public static final Long FILE_ID = 1L;
    private static final String RESULT_JSON_STRING = "{\"fileName\":\"originalFileName\",\"totalDatasets\":1,\"errorDatasets\":0,\"dataSets\":[{\"dataSetName\":\"dataSetName\",\"sectionName\":\"sectionName\",\"totalRows\":0,\"errorRows\":0,\"dataRows\":[{\"rowNum\":1,\"data\":{\"securityName\":\"BOOZ ALLEN\",\"apirCd\":\"apirCd123\",\"absPortfolioWeight\":\"67\"},\"containsErrors\":false},{\"rowNum\":1,\"data\":{\"securityName\":\"BOOZ ALLEN\",\"apirCd\":\"apirCd123\",\"absPortfolioWeight\":\"67\"},\"containsErrors\":false}],\"containsErrors\":false}]}";
    public static final byte[] RESULT_CONTENTS = FileUtil.gzipCompress(RESULT_JSON_STRING.getBytes());
    public static final String FILE_CONTENTS =  "fileContent";
    public static final byte[] FILE_CONTENTS_ZIP =  FileUtil.gzipCompress(FILE_CONTENTS.getBytes());
    private static final long LAST_PROCESSED_FILE_ID = 1L;
    private static final long QUEUE_DEPTH = 1L;
    private static final String QUEUED_STATUS = "QUEUED";
    public static final String ORIGINAL_FILE_NAME = "originalFileName";
    private static final String FAIL_REASON = "failReason";
    private static final long BATCH_ID = 1L;
    private static final long ID_LONG = 1L;
    private static final String QUEUED = QUEUED_STATUS;
    private static final int TOTAL_DATASETS = 1;
    private static final int ERROR_DATASETS = 1;
    private static final String DATA_SET_NAME = "dataSetName";
    private static final String SECTION_NAME = "sectionName";
    private static final String ISIN = "isin";
    private static final String SEDOL = "sedol";
    private static final String SECURITY_NAME_MESSAGE = "securityName  must be between 0 and 20 characters";
    private static final String SECURITY_NAME_RULE = "securityName.length() > 20 ";
    public static final String SECURITY_NAME = "securityName";
    public static final String APIR_CD = "apirCd";
    private static final String APIR_CD_LENGTH_9_EXPRESSION = "apirCd.length() > 9";
    private static final String ERROR_MSG = "apirCd  must be between 0 and 9 characters";
    protected static final String SOURCE_NAME = "sourceName";
    private static final int HEADER_START_ROW = 1;
    private static final int DATA_START_ROW = 2;
    protected static final String FUND_NAME = "fundName";
    protected static final String APIR_CODE = "apirCd";
    protected static final String FIELD_NAME = "fieldName";
    private static final int ROW_NUM = 1;
    private static final int COL_NUM = 1;

    private static final Date today = new Date();

    public static ValidationRequest getValidationRequest() {
        List<ValidationRule> validationRules = getValidationRules();
        ValidationDTO holding = getHolding();
        ValidationRequest validationRequest = new ValidationRequest(holding, validationRules);
        validationRequest.setValidationDTO(holding);
        validationRequest.setValidationRules(validationRules);
        return validationRequest;
    }

    public static List<ValidationRule> getValidationRules() {
        List<ValidationRule> validationRules = new ArrayList<ValidationRule>();
        validationRules.add(getValidationRule());
        validationRules.add(getSecurityNameValidationRule());
        validationRules.add(getISINValidationRule());
        return validationRules;
    }

    public static ValidationDTO getHolding() {
        ValidationDTO holding = new ValidationDTO();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put(APIR_CD, "apirCd123");
        data.put("securityName", "BOOZ ALLEN");
        data.put(ISIN, "US0378331004");
        holding.setData(data);
        return holding;
    }

    public static ValidationRule getValidationRule() {
        ValidationRule validationRule = new ValidationRule(APIR_CD, APIR_CD_LENGTH_9_EXPRESSION, ERROR_MSG);
        validationRule.setKey(APIR_CD);
        validationRule.setExpression(APIR_CD_LENGTH_9_EXPRESSION);
        validationRule.setMessage(ERROR_MSG);
        return validationRule;
    }

    public static ValidationRule getSecurityNameValidationRule() {
        ValidationRule validationRule = new ValidationRule("", "", "");
        validationRule.setKey(SECURITY_NAME);
        validationRule.setExpression(SECURITY_NAME_RULE);
        validationRule.setMessage(SECURITY_NAME_MESSAGE);
        return validationRule;
    }

    public static ValidationRule getISINValidationRule() {
        ValidationRule validationRule = new ValidationRule("", "", "");
        validationRule.setKey("#isin");
        validationRule.setExpression("#isValidISIN(#isin)");
        validationRule.setMessage("isin  ${validatedValue}  check digit is invalid");
        return validationRule;
    }

    public static ColumnDefinition getColumnDefinition() {
        ColumnDefinition columnsDTO = new ColumnDefinition();
        columnsDTO.setSourceName(SOURCE_NAME);
        columnsDTO.setColumnIdx(0);
        return columnsDTO;
    }

    public static ReportDefinition getReportDefinition() {
        ReportDefinition reportDefinition = new ReportDefinition();
        reportDefinition.setColumnDefinitions(createColumnDefs());
        reportDefinition.setHeaderStartRow(HEADER_START_ROW);
        reportDefinition.setDataStartRow(DATA_START_ROW);
        reportDefinition.setValidationRules(getValidationRules());
        return reportDefinition;
    }

    private static List<ColumnDefinition> createColumnDefs() {
        List<ColumnDefinition> columns = new ArrayList<ColumnDefinition>();
        columns.add(createColumnDef("APIR Code", APIR_CODE));
        columns.add(createColumnDef("Fund Name", FUND_NAME));
        columns.add(createColumnDef("SEDOL", SEDOL));
        columns.add(createColumnDef("Security Name", SECURITY_NAME));
        columns.add(createColumnDef("Absolute Portfolio Weight (%)", "absPortfolioWeight"));
        columns.add(createColumnDef("Relative Portfolio Weight (%)", "relPortfolioWeight"));
        columns.add(createColumnDef("Holding Date", "holdingDate"));

        return columns;
    }

    private static ColumnDefinition createColumnDef(String sourceName, String targetName) {
        ColumnDefinition columnDef = new ColumnDefinition();
        columnDef.setSourceName(sourceName);
        columnDef.setTargetName(targetName);
        return columnDef;
    }

    public static ValidationDTO getValidationDTO() {
        ValidationDTO holding = new ValidationDTO();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put(APIR_CD, "apirCd123");
        data.put("securityName", "BOOZ ALLEN");
        data.put("absPortfolioWeight", "67");
        holding.setData(data);
        holding.setRowNum(ROW_NUM);
        return holding;
    }

    public static FileDTO getFileDTO() {
        FileDTO fileDTO = new FileDTO();
        fileDTO.setId(ID_LONG);
        fileDTO.setStatus(QUEUED);
        fileDTO.setResultDTO(getResultDTO());
        return fileDTO;
    }

    public static List<FileDTO> getFileDTOs() {
        List<FileDTO> fileDTOs = new ArrayList<FileDTO>();
        fileDTOs.add(getFileDTO());
        return fileDTOs;
    }

    public static ResultDTO getResultDTO() {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setFileName(ORIGINAL_FILE_NAME);
        resultDTO.setDataSets(getDataSets());
        resultDTO.setTotalDatasets(TOTAL_DATASETS);
        resultDTO.setTotalDatasets(ERROR_DATASETS);
        return resultDTO;
    }

    public static DataSetDTO getDataSetDTO() {
        DataSetDTO dataSetDTO = new DataSetDTO();
        dataSetDTO.setSheetName(DATA_SET_NAME);
        dataSetDTO.setDataSetName(SECTION_NAME);
        dataSetDTO.setDataRows(getValidationDTOs());
        return dataSetDTO;
    }

    public static List<ValidationDTO> getValidationDTOs() {
        List<ValidationDTO> validationDTOs = new ArrayList<ValidationDTO>();
        validationDTOs.add(getValidationDTO());
        validationDTOs.add(getValidationDTO());
        return validationDTOs;
    }

    public static List<ValidationError> getValidationErrors() {
        List<ValidationError> validationErrors = new ArrayList<ValidationError>();
        validationErrors.add(getValidationError());
        return validationErrors;
    }

    public static ValidationError getValidationError() {
        ValidationError validationError = new ValidationError();
        validationError.setFieldName(FIELD_NAME);
        validationError.setRowNum(ROW_NUM);
        validationError.setColNum(COL_NUM);
        validationError.setMessage(SECURITY_NAME_MESSAGE);
        return validationError;
    }

    public static Date getToday() {
        return today;
    }

    public static List<DataSetDTO> getDataSets() {
        List<DataSetDTO> dataSets = new ArrayList<DataSetDTO>();
        dataSets.add(getDataSetDTO());
        return dataSets;
    }

    public static List<SectionDTO> getSectionDTOs() {
        List<SectionDTO> sectionDTOs = new ArrayList<SectionDTO>();
        sectionDTOs.add(getSectionDTO());
        return sectionDTOs;
    }

    public static SectionDTO getSectionDTO() {
        SectionDTO sectionDTO = new SectionDTO();
        sectionDTO.setSectionName(SECTION_NAME);
        sectionDTO.setValidationDTOs(getValidationDTOs());
        sectionDTO.setDataRows(getDataRows());
        return sectionDTO;
    }

    public static List<Map<String, Object>> getDataRows() {
        List<Map<String, Object>> dataRows = new ArrayList<Map<String, Object>>();
        dataRows.add(getDataRow());
        return dataRows;
    }

    public static Map<String, Object> getDataRow() {
        Map<String, Object> dataRow = new HashMap<String, Object>();
        dataRow.put(APIR_CD, "apirCd123");
        dataRow.put("securityName", "BOOZ ALLEN");
        dataRow.put("absPortfolioWeight", "0.12");
        dataRow.put("relPortfolioWeight", "0.45");
        return dataRow;
    }

    public static BatchDTO getBatchDTO() {
        BatchDTO batchDTO = new BatchDTO();
        batchDTO.setId(ID_LONG);
        batchDTO.setLastProcessedFileId(LAST_PROCESSED_FILE_ID);
        batchDTO.setLastProcessedFileTimeStamp(getLastProcessedDate());
        batchDTO.setQueueDepth(QUEUE_DEPTH);
        batchDTO.setFiles(getFileDTOs());
        batchDTO.setStatus(QUEUED_STATUS);
        return batchDTO;
    }

    private static Date getLastProcessedDate() {
        LocalDate ld = LocalDate.of(2015, 02, 20);
        Date date = java.util.Date.from(ld.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
        return date;
    }

    public static BatchEntity getBatchEntity() {
        BatchEntity batchEntity = new BatchEntity();
        batchEntity.setId(BATCH_ID);
        return batchEntity;
    }

    public static FileEntity getFileEntity() {
        FileEntity fileEntity = new FileEntity();
        fileEntity.setId(ID_LONG);
        fileEntity.setBatchId(BATCH_ID);
        fileEntity.setInsertDate(today);
        fileEntity.setLastModified(today);
        fileEntity.setStatus(QUEUED_STATUS);
        fileEntity.setFailReason(FAIL_REASON);
        fileEntity.setFileContentEntity(getFileContentEntity());
        fileEntity.setErrorDatasets(ERROR_DATASETS);
        fileEntity.setTotalDatasets(TOTAL_DATASETS);
        fileEntity.setOriginalFileName(ORIGINAL_FILE_NAME);
        return fileEntity;
    }

    public static List<FileEntity> getFileEntities() {
        List<FileEntity> fileEntities = new ArrayList<FileEntity>();
        fileEntities.add(getFileEntity());
        return fileEntities;
    }

    public static FileContentEntity getFileContentEntity() {
        FileContentEntity fileContentEntity = new FileContentEntity();
        fileContentEntity.setId(ID_LONG);
        fileContentEntity.setFileContent(FILE_CONTENTS_ZIP);
        fileContentEntity.setResultContent(RESULT_CONTENTS);
        return fileContentEntity;
    }

    public static QueueItemEntity getQueueItemEntity() {
        QueueItemEntity queueItemEntity = new QueueItemEntity();
        queueItemEntity.setId(QUEUE_ITEM_ID);
        queueItemEntity.setFileId(FILE_ID);
        return queueItemEntity;
    }

    public static ExportFileDTO getExportFileDTO() {
        ExportFileDTO exportFileDTO = new ExportFileDTO();
        exportFileDTO.setQuestionId(QUESTION_ID);
        List<Long> batchIds = new ArrayList<Long>();
        batchIds.add(FILE_ID);
        exportFileDTO.setBatchIds(batchIds );
        return exportFileDTO;
    }

    public static QuestionnaireDTO getQuestionnaireDTO() {
        QuestionnaireDTO questionnaireDTO= new QuestionnaireDTO();
        questionnaireDTO.setQuestionnaireName(QUESTIONNAIRE_NAME);
        List<ExportFileDTO> files = new ArrayList<ExportFileDTO>();
        files.add(getExportFileDTO());
        questionnaireDTO.setFiles(files );
        return questionnaireDTO;
    }

    public static ExportQuestionnaireDTO getExportQuestionnaireDTO() {
        ExportQuestionnaireDTO exportQuestionnaireDTO = new ExportQuestionnaireDTO();
        List<QuestionnaireDTO> questionnaires = new ArrayList<QuestionnaireDTO>();
        questionnaires.add(getQuestionnaireDTO());
        exportQuestionnaireDTO.setQuestionnaires(questionnaires );
        return exportQuestionnaireDTO;
    }

}
