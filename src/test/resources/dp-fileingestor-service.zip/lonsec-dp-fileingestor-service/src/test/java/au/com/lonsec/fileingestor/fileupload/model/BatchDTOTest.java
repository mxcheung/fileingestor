package au.com.lonsec.fileingestor.fileupload.model;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class BatchDTOTest extends FileUploadTst  {


    private final static String JSON_STRING = "{\"id\":1,\"status\":\"QUEUED\",\"queueDepth\":1,\"lastProcessedFileId\":1,\"lastProcessedFileTimeStamp\":1424350800000,\"files\":[{\"id\":1,\"status\":\"QUEUED\",\"totalDatasets\":0,\"errorDatasets\":0,\"resultDTO\":{\"fileName\":\"originalFileName\",\"totalDatasets\":1,\"errorDatasets\":0,\"dataSets\":[{\"dataSetName\":\"dataSetName\",\"sectionName\":\"sectionName\",\"totalRows\":0,\"errorRows\":0,\"dataRows\":[{\"rowNum\":1,\"data\":{\"securityName\":\"BOOZ ALLEN\",\"apirCd\":\"apirCd123\",\"absPortfolioWeight\":\"67\"},\"containsErrors\":false},{\"rowNum\":1,\"data\":{\"securityName\":\"BOOZ ALLEN\",\"apirCd\":\"apirCd123\",\"absPortfolioWeight\":\"67\"},\"containsErrors\":false}],\"containsErrors\":false}]}}]}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
        batchDTO = getBatchDTO();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        String json = this.mapper.writeValueAsString(batchDTO);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
    	batchDTO = mapper.readValue(JSON_STRING, BatchDTO.class);
        assertEquals(1L,batchDTO.getId().longValue());
    }


}
