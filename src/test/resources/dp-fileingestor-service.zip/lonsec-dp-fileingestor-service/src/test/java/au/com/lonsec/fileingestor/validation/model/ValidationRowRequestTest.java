package au.com.lonsec.fileingestor.validation.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.fileupload.model.ValidationDTO;

public class ValidationRowRequestTest extends ValidationRequestTst  {


    private final static String JSON_STRING = "{\"validationDTO\":{\"data\":{\"securityName\":\"BOOZ ALLEN\",\"apirCd\":\"apirCd123\",\"isin\":\"US0378331004\"},\"containsErrors\":false},\"validationRules\":[{\"key\":\"apirCd\",\"expression\":\"apirCd.length() > 9\",\"message\":\"apirCd  must be between 0 and 9 characters\"},{\"key\":\"securityName\",\"expression\":\"securityName.length() > 20 \",\"message\":\"securityName  must be between 0 and 20 characters\"},{\"key\":\"#isin\",\"expression\":\"#isValidISIN(#isin)\",\"message\":\"isin  ${validatedValue}  check digit is invalid\"}]}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        ValidationRequest validationRequest = getValidationRequest();
        ValidationDTO rowData = validationRequest.getValidationDTO();
        List<ValidationRule> validationRules = validationRequest.getValidationRules();
        assertNotNull(rowData);
        assertEquals(3, validationRules.size());
        String json = this.mapper.writeValueAsString(validationRequest);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        ValidationRequest validationRule = mapper.readValue(JSON_STRING, ValidationRequest.class);
        Map<String, Object> data = validationRule.getValidationDTO().getData();
        assertEquals("apirCd123", data.get(APIR_CD));
    }


}
