package au.com.lonsec.fileingestor.filespec.service;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.filespec.FileSpecConfig;

public class FileSpecConfigTest {

	private final static String JSON_STRING = "{\"filespecs\":{\"portfolioHoldingDef\":\"filespec/portfolioHoldingDef.json\"}}";

	private FileSpecConfig config;

	private Map<String, String> filespecs;

	private ObjectMapper mapper;

	@Before
	public void setup() {
		mapper = new ObjectMapper();
		filespecs = new HashMap<String, String>();
		filespecs.put("portfolioHoldingDef", "filespec/portfolioHoldingDef.json");
		config = new FileSpecConfig();
		config.setFilespecs(filespecs);
	}

	@Test
	public void shouldSerialize() throws JsonProcessingException {
		String json = this.mapper.writeValueAsString(config);
		assertEquals(JSON_STRING, json);
	}

	@Test
	public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
		FileSpecConfig fileSpecConfig = mapper.readValue(JSON_STRING, FileSpecConfig.class);
		assertEquals(1, fileSpecConfig.getFilespecs().size());
	}


}
