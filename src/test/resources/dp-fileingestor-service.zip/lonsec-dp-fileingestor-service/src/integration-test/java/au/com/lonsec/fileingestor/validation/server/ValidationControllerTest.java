package au.com.lonsec.fileingestor.validation.server;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.fileupload.FileIngestorService;
import au.com.lonsec.fileingestor.validation.model.ValidationRequest;
import au.com.lonsec.fileingestor.validation.server.ValidationController;
import au.com.lonsec.fileingestor.validation.server.ValidationService;
import au.com.lonsec.fileingestor.validation.server.ValidationURI;

@Ignore
@RunWith(SpringRunner.class)
@WebMvcTest(value = ValidationController.class, secure = false)
public class ValidationControllerTest {

	protected static final String SEGMENT_CD = "SR";
	protected static final String FILE_SPEC = "Holding";

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private FileIngestorService fileIngestorService;

	@MockBean
	private ValidationService validationService;

	private ValidationRequest validationRequest;

	@Before
	public void setup() {
		validationRequest = DomainStereotypeUtil.getValidationRequest();
	}
	
    @Test
    public void shouldPostValidationRequest() throws Exception {
        MockHttpServletResponse response = checkEndpoint( ValidationURI.POST_VALIDATE_MAPPING);
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }


    private MockHttpServletResponse checkEndpoint(String endpoint) throws JsonProcessingException, Exception {
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(validationRequest);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(ValidationURI.VALIDATION_BASE_CONTEXT + endpoint).accept(MediaType.APPLICATION_JSON)
                .content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }


}
