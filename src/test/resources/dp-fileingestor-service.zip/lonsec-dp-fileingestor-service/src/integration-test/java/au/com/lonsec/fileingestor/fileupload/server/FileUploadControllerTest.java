package au.com.lonsec.fileingestor.fileupload.server;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.fileexport.model.ExportQuestionnaireDTO;
import au.com.lonsec.fileingestor.fileupload.FileContentEntity;
import au.com.lonsec.fileingestor.fileupload.FileExportService;
import au.com.lonsec.fileingestor.fileupload.FileIngestorService;
import au.com.lonsec.fileingestor.fileupload.FileProcessorService;
import au.com.lonsec.fileingestor.fileupload.FileStatusType;
import au.com.lonsec.fileingestor.fileupload.FileStoreAndFowardService;
import au.com.lonsec.fileingestor.fileupload.model.BatchDTO;
import au.com.lonsec.fileingestor.fileupload.model.FileDTO;
import au.com.lonsec.fileingestor.fileupload.model.ResultDTO;

@RunWith(SpringRunner.class)
@WebMvcTest(value = FileUploadController.class, secure = false)
public class FileUploadControllerTest {

    private static final Long BATCH_ID = 1L;
    private static final long FILE_ID = 1L;

    protected static final String SEGMENT_CD = "SR";

    private static final String FILE_SPEC_DEFINITION = "portfolioHoldingDef";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FileIngestorService fileIngestorService;

    @MockBean
    private FileProcessorService fileProcessorService;
    
    @MockBean
    private FileExportService fileExportService;
    
    @MockBean
    private FileStoreAndFowardService fileStoreAndFowardService;

    @Before
    public void setup() {
    }

    @Test
    public void shouldSaveFileUpload() throws Exception {
        ResultDTO result = new ResultDTO();
        result.setFileName("DataSet");
        MockMultipartFile multiPFImage = new MockMultipartFile("file", "abcpic.png", "img/png", "Generate bytes to simulate a picture".getBytes());
        when(fileIngestorService.importData(any(MultipartFile.class), any(String.class))).thenReturn(result);
        when(fileProcessorService.importData(any(MultipartFile.class), any(String.class))).thenReturn(result);

        mockMvc.perform(MockMvcRequestBuilders.fileUpload(FileUploadURI.FILEINGESTOR_BASE_CONTEXT + FileUploadURI.POST_UPLOAD_MAPPING)
                .file(multiPFImage).param("name", FILE_SPEC_DEFINITION)).andExpect(status().isAccepted())
                .andExpect(content().string(containsString("DataSet")));
    }

    @Test
    public void shouldSaveMultiFileUpload() throws Exception {
        BatchDTO result = DomainStereotypeUtil.getBatchDTO();
        MockMultipartFile multiPFImage = new MockMultipartFile("file", "abcpic.png", "img/png", "Generate bytes to simulate a picture".getBytes());
        when(fileStoreAndFowardService.storeAndFwd(any(MultipartFile[].class), any(Long.class), any(Boolean.class))).thenReturn(result);

        mockMvc.perform(MockMvcRequestBuilders.fileUpload(FileUploadURI.FILEINGESTOR_BASE_CONTEXT + FileUploadURI.POST_MULTI_FILEUPLOAD_MAPPING)
                .file(multiPFImage).param("batchId", BATCH_ID.toString())).andExpect(status().isAccepted())
                .andExpect(content().string(containsString(FileStatusType.QUEUED.name())));
    }

    
    
    @Test
    public void shouldExportFiles() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        FileContentEntity fileContent = DomainStereotypeUtil.getFileContentEntity();
        byte[] fileBytes = fileContent.getFileContent();
        ExportQuestionnaireDTO exportQuestionnaireDTO = DomainStereotypeUtil.getExportQuestionnaireDTO();
        String plainTextJson = mapper.writeValueAsString(exportQuestionnaireDTO);
        when(fileExportService.exportFiles(any(ExportQuestionnaireDTO.class))).thenReturn(fileBytes);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(FileUploadURI.FILEINGESTOR_BASE_CONTEXT + FileUploadURI.POST_FILE_DOWNLOAD_MAPPING).accept(MediaType.APPLICATION_JSON)
                .content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse(); 
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    

    
    @Test
    public void shouldStoreMultiFileUpload() throws Exception {
        BatchDTO result = DomainStereotypeUtil.getBatchDTO();
        MockMultipartFile multiPFImage = new MockMultipartFile("file", "abcpic.png", "img/png", "Generate bytes to simulate a picture".getBytes());
        when(fileStoreAndFowardService.storeAndFwd(any(MultipartFile[].class), any(Long.class), any(Boolean.class))).thenReturn(result);

        mockMvc.perform(
                MockMvcRequestBuilders.fileUpload(FileUploadURI.FILEINGESTOR_BASE_CONTEXT + FileUploadURI.POST_STATIC_MULTI_FILEUPLOAD_MAPPING)
                        .file(multiPFImage).param("batchId", BATCH_ID.toString()))
                .andExpect(status().isAccepted()).andExpect(content().string(containsString(FileStatusType.QUEUED.name())));
    }

    @Test
    public void shouldGetBatchStatus() throws Exception {
        BatchDTO batchDTO = DomainStereotypeUtil.getBatchDTO();
        when(fileIngestorService.getBatchSummary(BATCH_ID)).thenReturn(batchDTO);
        MockHttpServletResponse response = getEndpoint(FileUploadURI.GET_BATCH_STATUS_MAPPING, "batchId", String.valueOf(BATCH_ID));
        assertEquals(HttpStatus.OK.value(), response.getStatus());

    }

    @Test
    public void shouldGetFileErrors() throws Exception {
        FileDTO fileDTO = DomainStereotypeUtil.getFileDTO();
        when(fileIngestorService.getFileErrors(BATCH_ID)).thenReturn(fileDTO);
        MockHttpServletResponse response = getEndpoint(FileUploadURI.GET_FILE_ERRORS_MAPPING, "fileId", String.valueOf(FILE_ID));
        assertEquals(HttpStatus.OK.value(), response.getStatus());

    }

    private MockHttpServletResponse getEndpoint(String requestMapping, String name, String value) throws JsonProcessingException, Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(FileUploadURI.FILEINGESTOR_BASE_CONTEXT + requestMapping)
                .header("segmentCd", SEGMENT_CD).param(name, value).accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

}
