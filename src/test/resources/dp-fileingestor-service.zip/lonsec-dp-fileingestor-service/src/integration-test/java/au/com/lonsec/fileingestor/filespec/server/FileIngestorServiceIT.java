package au.com.lonsec.fileingestor.filespec.server;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import au.com.lonsec.fileingestor.AbstractIntegrationTest;
import au.com.lonsec.fileingestor.filespec.FileSpecService;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.FileIngestorService;
import au.com.lonsec.fileingestor.fileupload.FileProcessorService;
import au.com.lonsec.fileingestor.fileupload.model.DataSetDTO;
import au.com.lonsec.fileingestor.poi.PoiService;


public class FileIngestorServiceIT extends AbstractIntegrationTest {

    private InputStream excelFileToRead;

    @Autowired
    private FileIngestorService fileIngestorService;

    @Autowired
    private FileProcessorService fileProcessorService;


    @Autowired
    private FileSpecService fileSpecService;
    
    @Autowired
    private PoiService poiService;

    @Before
    public void setup() throws IOException {
        assertNotNull(fileIngestorService);
    }
    
    @Test
    public void shouldLoadLonsecEquityHolding() throws IOException, InvalidFormatException {
        excelFileToRead = getClass().getResourceAsStream("/xssf/lonsec/Holding Equity 456_20171106012756_with_gaps.xls");
        ReportDefinition reportDefinition = fileSpecService.getReportDefinition("portfolioHoldingDef");
        List<Sheet> sheets = poiService.extractSheets(excelFileToRead,"xls");
        assertEquals(4, sheets.size());
        List<DataSetDTO> result = fileProcessorService.processSheets(reportDefinition, sheets);
        assertEquals(1, result.size());
        DataSetDTO dataSetDTO = result.get(0);
        assertEquals("Equity", dataSetDTO.getDataSetName());
        assertEquals(723, dataSetDTO.getTotalRows());
        assertEquals(178, dataSetDTO.getErrorRows());
    }
    
}
